
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-1 shadow-sm p-4">
                <div class="card-header border-0 bg-transparent text-center">
                    <h5><?php echo app('translator')->get('Choose Category Below.'); ?></h5>
                   
                </div>
                <div class="card-body">
                    <ul class="select-menu-list">
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="has-drop-menu">
                          <a href="javascript:void(0)">
                            <img src="<?php echo e(getImage('assets/images/category/'.$cat->image)); ?>" alt="image" class="select-menu-img">
                            <span><?php echo e(__($cat->name)); ?></span>
                          </a>
                          <ul class="drop-menu">
                            <?php $__currentLoopData = $cat->subcategories->where('type',$flag); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <li>
                              <a href="<?php echo e(route('user.post.ad.location',[$type,$subcat->slug])); ?>">
                                <i class="las la-caret-right"></i>
                                <span><?php echo e(__($subcat->name)); ?></span>
                              </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                          </ul>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-center"><?php echo app('translator')->get('No categories available'); ?></li>
                        <?php endif; ?>
                      </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/ads/postAdCategory.blade.php ENDPATH**/ ?>