<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card shadow-sm  border-0">
           <div class="card-header bg--sec">
                <?php echo app('translator')->get('Profile Setting'); ?>
           </div>
           <div class="card-body">
            <form class="register" action="" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row justify-content-center align-items-center mt-3">
                    <div class="col-xl6 col-lg-6 col-md-6 col-sm-6">
                        <div class="form-group">
                            <div class="image-upload">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview"  style="background-image: url(<?php echo e(getImage(imagePath()['profile']['user']['path'].'/'. $user->image,imagePath()['profile']['user']['size'])); ?>)">
                                            <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" class="profilePicUpload" name="image" id="profilePicUpload1" accept=".png, .jpg, .jpeg">
                                        <label for="profilePicUpload1"  class="bg--base text-white"><?php echo app('translator')->get('Upload Image'); ?></label>
                                        <small class="mt-2 text-facebook"><?php echo app('translator')->get('Supported files'); ?>: <b><?php echo app('translator')->get('jpeg'); ?>, <?php echo app('translator')->get('jpg'); ?>.</b> <?php echo app('translator')->get('Image will be resized into 400x400px'); ?> </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-sm-6">
                        <label for="InputFirstname" class="col-form-label"><?php echo app('translator')->get('First Name'); ?>:</label>
                        <input type="text" class="form--control" id="InputFirstname" name="firstname" placeholder="<?php echo app('translator')->get('First Name'); ?>" value="<?php echo e($user->firstname); ?>" >
                    </div>
                    <div class="form-group col-sm-6">
                        <label for="lastname" class="col-form-label"><?php echo app('translator')->get('Last Name'); ?>:</label>
                        <input type="text" class="form--control" id="lastname" name="lastname" placeholder="<?php echo app('translator')->get('Last Name'); ?>" value="<?php echo e($user->lastname); ?>">
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-sm-6">
                        <label for="email" class="col-form-label"><?php echo app('translator')->get('E-mail Address'); ?>:</label>
                        <input type="email" class="form--control" id="email" name="email" placeholder="<?php echo app('translator')->get('E-mail Address'); ?>" value="<?php echo e($user->email); ?>" readonly>
                    </div>
                    <div class="form-group col-sm-6">
                        <input type="hidden" id="track" name="country_code">
                        <label for="phone" class="col-form-label"><?php echo app('translator')->get('Mobile Number'); ?></label>
                        <input type="tel" class="form--control pranto-control" id="phone" name="mobile" value="<?php echo e($user->mobile); ?>" placeholder="<?php echo app('translator')->get('Your Contact Number'); ?>" readonly>
                    </div>
                    <input type="hidden" name="country" id="country" class="form--control d-none" value="<?php echo e(@$user->address->country); ?>">
                </div>
                <div class="row">
                    <div class="form-group col-sm-6">
                        <label for="address" class="col-form-label"><?php echo app('translator')->get('Address'); ?>:</label>
                        <input type="text" class="form--control" id="address" name="address" placeholder="<?php echo app('translator')->get('Address'); ?>" value="<?php echo e(@$user->address->address); ?>" required="">
                    </div>
                    <div class="form-group col-sm-6">
                        <label for="state" class="col-form-label"><?php echo app('translator')->get('State'); ?>:</label>
                        <input type="text" class="form--control" id="state" name="state" placeholder="<?php echo app('translator')->get('state'); ?>" value="<?php echo e(@$user->address->state); ?>" required="">
                    </div>
                </div>


                <div class="row">
                    <div class="form-group col-sm-6">
                        <label for="zip" class="col-form-label"><?php echo app('translator')->get('Zip Code'); ?>:</label>
                        <input type="text" class="form--control" id="zip" name="zip" placeholder="<?php echo app('translator')->get('Zip Code'); ?>" value="<?php echo e(@$user->address->zip); ?>" required="">
                    </div>

                    <div class="form-group col-sm-6">
                        <label for="city" class="col-form-label"><?php echo app('translator')->get('City'); ?>:</label>
                        <input type="text" class="form--control" id="city" name="city" placeholder="<?php echo app('translator')->get('City'); ?>" value="<?php echo e(@$user->address->city); ?>" required="">
                    </div>

                </div>
                
                <div class="form-group row pt-3">
                    <div class="col-sm-12 text-center">
                        <button type="submit" class="btn  btn--base btn-md w-100"><?php echo app('translator')->get('Update Profile'); ?></button>
                    </div>
                </div>
            </form>
           </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/profile-setting.blade.php ENDPATH**/ ?>