<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row ">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg--sec">
                        <?php echo app('translator')->get('Change Password'); ?>
                    </div>
                    <div class="card-body">
                        <form action="" method="post" class="register">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="password"><?php echo app('translator')->get('Current Password'); ?></label>
                                <input id="password" type="password" class="form--control" placeholder="<?php echo app('translator')->get('Current Password'); ?>" name="current_password" required autocomplete="current-password">
                            </div>
                            <div class="form-group">
                                <label for="password"><?php echo app('translator')->get('Password'); ?></label>
                                <input id="password" type="password" class="form--control" placeholder="<?php echo app('translator')->get('New Password'); ?>" name="password" required autocomplete="current-password">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password"><?php echo app('translator')->get('Confirm Password'); ?></label>
                                <input id="password_confirmation" type="password" placeholder="<?php echo app('translator')->get('Confirm Password'); ?>" class="form--control" name="password_confirmation" required autocomplete="current-password">
                            </div>
                            <div class="form-group text-end">
                                <input type="submit" class="mt-3 btn btn--base btn-md" value="<?php echo app('translator')->get('Change Password'); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/password.blade.php ENDPATH**/ ?>