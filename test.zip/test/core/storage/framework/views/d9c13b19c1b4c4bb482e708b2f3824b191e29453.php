<?php
    $ad = session('ad') ?? null;
    $pkg = session('pkg') ?? null;
?>

<?php $__env->startSection('content'); ?>
   
        <div class="row">
            <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card card-deposit border-0 shadow">
                        <h5 class="card-header bg--sec text-center"><?php echo e(__($data->name)); ?>

                        </h5>
                        <div class="card-body card-body-deposit">
                            <img src="<?php echo e($data->methodImage()); ?>" class="card-img-top" alt="<?php echo e(__($data->name)); ?>" class="w-100">
                        </div>
                        <div class="card-footer bg--sec text-center">
                            <a href="javascript:void(0)"  data-id="<?php echo e($data->id); ?>" data-resource="<?php echo e($data); ?>"
                               data-min_amount="<?php echo e(getAmount($data->min_amount)); ?>"
                               data-max_amount="<?php echo e(getAmount($data->max_amount)); ?>"
                               data-base_symbol="<?php echo e($data->baseSymbol()); ?>"
                               data-fix_charge="<?php echo e(getAmount($data->fixed_charge)); ?>"
                               data-percent_charge="<?php echo e(getAmount($data->percent_charge)); ?>" class=" text-white deposit" data-toggle="modal" data-target="#depositModal">
                                <?php echo app('translator')->get('Payment Now'); ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
   
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $(document).ready(function(){
            $('.deposit').on('click', function () {
                
                var id = $(this).data('id');
                var result = $(this).data('resource');
                var minAmount = $(this).data('min_amount');
                var maxAmount = $(this).data('max_amount');
                var baseSymbol = "<?php echo e(__($general->cur_text)); ?>";
                var fixCharge = $(this).data('fix_charge');
                var percentCharge = $(this).data('percent_charge');

                var depositLimit = `<?php echo app('translator')->get('Deposit Limit'); ?>: ${minAmount} - ${maxAmount}  ${baseSymbol}`;
                $('.depositLimit').text(depositLimit);
                var depositCharge = `<?php echo app('translator')->get('Charge'); ?>: ${fixCharge} ${baseSymbol}  ${(0 < percentCharge) ? ' + ' +percentCharge + ' % ' : ''}`;
                $('.depositCharge').text(depositCharge);
                $('.method-name').text(`<?php echo app('translator')->get('Payment By '); ?> ${result.name}`);
                $('.currency-addon').text(baseSymbol);


                $('.edit-currency').val(result.currency);
                $('.edit-method-code').val(result.method_code);
                $("#depositModal").modal('show')
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/payment/deposit.blade.php ENDPATH**/ ?>