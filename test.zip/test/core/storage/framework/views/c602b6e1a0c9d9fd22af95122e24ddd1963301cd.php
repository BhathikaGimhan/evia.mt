<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 d-flex justify-content-end">
            <form action="">
               <div class="input-group">
                 <input class="form-control outline-0 shadow-none" value="<?php echo e($search??''); ?>" type="text" name="search" placeholder="<?php echo app('translator')->get('Search by trx'); ?>" required>
                  <button type="submit" class="input-group-text bg--sec"><i class="las la-search"></i></button>
               </div>
            </form>
          </div>
        <div class="col-lg-12">
          <div class="table-responsive--md">
            <table class="table custom--table">
              <thead>
                <tr>
                    <th scope="col"><?php echo app('translator')->get('Transaction ID'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Gateway'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Time'); ?></th>
                    <th scope="col"> <?php echo app('translator')->get('MORE'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php if(count($logs) >0): ?>
                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="#<?php echo app('translator')->get('Trx'); ?>"><?php echo e($data->trx); ?></td>
                            <td data-label="<?php echo app('translator')->get('Gateway'); ?>"><?php echo e(__(@$data->gateway->name)); ?></td>
                            <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                <strong><?php echo e(getAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?></strong>
                            </td>
                            <td>
                                <?php if($data->status == 1): ?>
                                    <span class="badge badge--success"><?php echo app('translator')->get('Complete'); ?></span>
                                <?php elseif($data->status == 2): ?>
                                    <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                <?php elseif($data->status == 3): ?>
                                    <span class="badge badge--danger"><?php echo app('translator')->get('Cancel'); ?></span>
                                <?php endif; ?>

                                <?php if($data->admin_feedback != null): ?>
                                    <button class="btn-info btn-rounded  badge detailBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"><i class="fa fa-info"></i></button>
                                <?php endif; ?>

                            </td>
                            <td data-label="<?php echo app('translator')->get('Time'); ?>">
                                <i class="fa fa-calendar"></i> <?php echo e(showDateTime($data->created_at)); ?>

                            </td>

                            <?php
                                $details = ($data->detail != null) ? json_encode($data->detail) : null;
                            ?>

                            <td data-label="<?php echo app('translator')->get('Details'); ?>">
                                <a href="javascript:void(0)" class="icon-btn btn--primary  approveBtn"
                                    data-info="<?php echo e($details); ?>"
                                    data-id="<?php echo e($data->id); ?>"
                                    data-amount="<?php echo e(getAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?>"
                                    data-charge="<?php echo e(getAmount($data->charge)); ?> <?php echo e(__($general->cur_text)); ?>"
                                    data-after_charge="<?php echo e(getAmount($data->amount + $data->charge)); ?> <?php echo e(__($general->cur_text)); ?>"
                                    data-rate="<?php echo e(getAmount($data->rate)); ?> <?php echo e(__($data->method_currency)); ?>"
                                    data-payable="<?php echo e(getAmount($data->final_amo)); ?> <?php echo e(__($data->method_currency)); ?>">
                                    <i class="fa fa-desktop"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="100%"> <?php echo app('translator')->get('No results found'); ?>!</td>
                        </tr>
                    <?php endif; ?>
                
              </tbody>
            </table>
          </div>
        </div>
        <?php echo e(paginateLinks($logs,'partials.paginate')); ?>

      </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        $('.approveBtn').on('click', function() {
            var modal = $('#approveModal');
            modal.find('.withdraw-amount').text($(this).data('amount'));
            modal.find('.withdraw-charge').text($(this).data('charge'));
            modal.find('.withdraw-after_charge').text($(this).data('after_charge'));
            modal.find('.withdraw-rate').text($(this).data('rate'));
            modal.find('.withdraw-payable').text($(this).data('payable'));
            var list = [];
            var details =  Object.entries($(this).data('info'));

            var ImgPath = "<?php echo e(asset(imagePath()['verify']['deposit']['path'])); ?>/";
            var singleInfo = '';
            for (var i = 0; i < details.length; i++) {
                if (details[i][1].type == 'file') {
                    singleInfo += `<li class="list-group-item">
                                        <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <img src="${ImgPath}/${details[i][1].field_name}" alt="<?php echo app('translator')->get('Image'); ?>" class="w-100">
                                    </li>`;
                }else{
                    singleInfo += `<li class="list-group-item">
                                        <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <span class="font-weight-bold ml-3">${details[i][1].field_name}</span> 
                                    </li>`;
                }
            }
            
            if (singleInfo)
            {
                modal.find('.withdraw-detail').html(`<br><strong class="my-3"><?php echo app('translator')->get('Payment Information'); ?></strong>  ${singleInfo}`);
            }else{
                modal.find('.withdraw-detail').html(`${singleInfo}`);
            }
            modal.modal('show');
        });
        
        $('.detailBtn').on('click', function() {
            var modal = $('#detailModal');
            var feedback = $(this).data('admin_feedback');
            modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
            modal.modal('show');
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/deposit_history.blade.php ENDPATH**/ ?>