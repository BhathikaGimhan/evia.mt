<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>