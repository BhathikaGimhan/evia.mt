
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-1 shadow-sm p-4">
                <div class="card-header border-0 bg-transparent text-center">
                    <h5><?php echo app('translator')->get('Welcome'); ?> <?php echo e(auth()->user()->firstname); ?>! <?php echo app('translator')->get('Let\'s post an ad.'); ?></h5>
                    <p class="mt-3"><?php echo app('translator')->get('Choose any option below'); ?></p>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-between"><a class="text--base" href="<?php echo e(route('user.post.ad.category','sell')); ?>"><?php echo app('translator')->get('Sell Service,item or property'); ?></a> <i class="las la-angle-right mt-1"></i></li>
                        <li class="list-group-item d-flex justify-content-between"><a class="text--base" href="<?php echo e(route('user.post.ad.category','rent')); ?>"><?php echo app('translator')->get('Rent Item or Service'); ?></a> <i class="las la-angle-right mt-1"></i></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/ads/postAdType.blade.php ENDPATH**/ ?>