<?php if(Route::currentRouteName()=='user.deposit'): ?>
<div class="modal fade" id="depositModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post">
        <div class="modal-content">
            <div class="modal-header bg--sec">
                <strong class="modal-title method-name" id="exampleModalLabel"></strong>
                <a href="javascript:void(0)" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
           
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <p class="text-danger depositLimit"></p>
                    <p class="text-danger depositCharge"></p>
                    <div class="form-group">
                        <input type="hidden" name="currency" class="edit-currency" value="">
                        <input type="hidden" name="method_code" class="edit-method-code" value="">
                    </div>
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Your Amount'); ?>:</label>
                        <div class="input-group">
                            <input id="amount" type="text" class="form--control" onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')" name="amount" placeholder="0.00" required=""  value="<?php echo e($pkg?getAmount($pkg->price):old('amount')); ?>" <?php echo e($pkg?'readonly':''); ?>>

                            <span class="input-group-text currency-addon addon-bg"><?php echo e(__($general->cur_text)); ?></span>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn--dark" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn-sm btn--primary"><?php echo app('translator')->get('Confirm'); ?></button>
                   
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/depositModal.blade.php ENDPATH**/ ?>