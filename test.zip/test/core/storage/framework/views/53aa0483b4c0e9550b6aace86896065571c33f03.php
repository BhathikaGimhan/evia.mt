
<?php if(Route::currentRouteName() == 'ad.details'): ?>
      
      <link rel="shortcut icon" href="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" type="image/x-icon">
      <link rel="apple-touch-icon" href="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <meta name="apple-mobile-web-app-title" content="<?php echo e($general->sitename($page_title)); ?>">
      
      <meta itemprop="name" content="<?php echo e($general->sitename($page_title)); ?>">
     
      <meta itemprop="description" content="<?php echo e(strip_tags($ad->description)); ?>">
      <meta itemprop="image" content="<?php echo e(getImage('assets/images/adimage/'.$ad->prev_image)); ?>">
      
      <meta property="og:type" content="website">
      <meta property="og:title" content="<?php echo e($ad->title); ?>">
      <meta property="og:description" content="<?php echo e(str_limit(strip_tags($ad->description,1000))); ?>">
      <meta property="og:image" content="<?php echo e(getImage('assets/images/adimage/'.$ad->prev_image)); ?>"/>
      <meta property="og:image:type" content="image/<?php echo e(pathinfo(getImage('assets/images/adimage/'.$ad->prev_image))['extension'] ?? 'jpg'); ?>" />
      <meta property="og:url" content="<?php echo e(url()->current()); ?>">
      
      <meta name="twitter:card" content="summary_large_image">
<?php endif; ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/partials/additionalSeo.blade.php ENDPATH**/ ?>