<?php $__env->startSection('content'); ?>
    
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg--sec d-flex justify-content-between"><?php echo e(__($page_title)); ?>

                        <a href="<?php echo e(route('ticket')); ?>" class="btn btn-sm btn--base">
                            <?php echo app('translator')->get('My Support Tickets'); ?>
                        </a>
                    </div>

                    <div class="card-body">
                        <form  action="<?php echo e(route('ticket.store')); ?>"  method="post" enctype="multipart/form-data" onsubmit="return submitUserForm();">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name"><?php echo app('translator')->get('Name'); ?></label>
                                    <input type="text" name="name" value="<?php echo e(@$user->firstname . ' '.@$user->lastname); ?>" class="form--control" placeholder="<?php echo app('translator')->get('Enter Name'); ?>" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="email"><?php echo app('translator')->get('Email address'); ?></label>
                                    <input type="email"  name="email" value="<?php echo e(@$user->email); ?>" class="form--control" placeholder="<?php echo app('translator')->get('Enter your Email'); ?>" required>
                                </div>

                                <div class="form-group col-md-12">
                                    <label for="website"><?php echo app('translator')->get('Subject'); ?></label>
                                    <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" class="form--control" placeholder="<?php echo app('translator')->get('Subject'); ?>" >
                                </div>
                                <div class="col-12 form-group">
                                    <label for="inputMessage"><?php echo app('translator')->get('Message'); ?></label>
                                    <textarea name="message" id="inputMessage" rows="6" class="form--control"><?php echo e(old('message')); ?></textarea>
                                </div>
                            </div>

                            <div class="row form-group ">
                                <div class="col-sm-9 file-upload">
                                    <label for="inputAttachments"><?php echo app('translator')->get('Attachments'); ?></label>
                                    <input type="file" name="attachments[]" id="inputAttachments" class="form-control mb-2" />
                                    <div id="fileUploadsContainer"></div>
                                    <p class="ticket-attachments-message text-muted">
                                        <?php echo app('translator')->get('Allowed File Extensions'); ?>: .<?php echo app('translator')->get('jpg'); ?>, .<?php echo app('translator')->get('jpeg'); ?>, .<?php echo app('translator')->get('png'); ?>, .<?php echo app('translator')->get('pdf'); ?>, .<?php echo app('translator')->get('doc'); ?>, .<?php echo app('translator')->get('docx'); ?>
                                    </p>
                                </div>

                                <div class="form-group col-sm-1">
                                    <label for="" class="d-block">&nbsp;</label>
                                    <button type="button" class="btn btn--success btn-sm" onclick="extraTicketAttachment()">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-md-12 text-end">
                                    <button class="btn btn--success btn-sm" type="submit" id="recaptcha" ><i class="fa fa-paper-plane"></i>&nbsp;<?php echo app('translator')->get('Submit'); ?></button>
                                    <button class=" btn btn--danger btn-sm" type="button" onclick="formReset()">&nbsp;<?php echo app('translator')->get('Cancel'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
 
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        function extraTicketAttachment() {
            $("#fileUploadsContainer").append('<input type="file" name="attachments[]" class="form-control my-3" required />')
        }
        function formReset() {
            window.location.href = "<?php echo e(url()->current()); ?>"
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/support/create.blade.php ENDPATH**/ ?>