<?php $__env->startSection('content'); ?>
<div class="create-ad-wrapper">
    <form action="<?php echo e(route('user.store.ad')); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>

      <input type="hidden" name="subcategory_id" value="<?php echo e($subcategory->id); ?>">
      <input type="hidden" name="district_id" value="<?php echo e($district->id); ?>">
      <input type="hidden" name="type" value="<?php echo e($type == 'sell'? 1 : 2); ?>">
     <div class="d-flex justify-content-between title">
       <h4 class=""><?php echo app('translator')->get('Ad Information'); ?></h4>
        <div class="">
          <small class="font-weight-bold h6"> <i class="las la-tag text--base"></i> <?php echo e($subcategory->name); ?></small>
          <small class="font-weight-bold h6"> <i class="las la-map-marker text--base"></i> <?php echo e($district->name); ?></small>
        </div>
     </div>
      <div class="row">

      <label class="mb-3 font-weight-bold"><?php echo app('translator')->get('Item Images'); ?></label>
       <div class="product-image-upload-container mb-2 d-flex justify-content-center">
         <div class="single-upload">
           <div class="center" >
             <div class="form-input">
               <label for="file-ip-1" data-toggle="tooltip" title="<?php echo app('translator')->get('Preview image'); ?>">
                 <img id="file-ip-1-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
                 <button type="button" class="imgRemove" onclick="myImgRemove(1)"></button>
               </label>
               <input type="file"  name="prev_image" id="file-ip-1" accept="image/*" onchange="showPreview(event, 1);">
             </div>
           </div>
         </div><!-- single-upload end -->
         <div class="single-upload" >
           <div class="center">
             <div class="form-input">
               <label for="file-ip-2" >
                 <img id="file-ip-2-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
                 <button type="button" class="imgRemove" onclick="myImgRemove(2)"></button>
               </label>
               <input type="file"  name="image[]" id="file-ip-2" accept="image/*" onchange="showPreview(event, 2);">
             </div>
           </div>
         </div><!-- single-upload end -->
         <div class="single-upload">
           <div class="form-input">
             <label for="file-ip-3">
               <img id="file-ip-3-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
               <button type="button" class="imgRemove" onclick="myImgRemove(3)"></button>
             </label>
             <input type="file" name="image[]" id="file-ip-3" accept="image/*" onchange="showPreview(event, 3);">
           </div>
         </div><!-- single-upload end -->
         <div class="single-upload">
           <div class="form-input">
             <label for="file-ip-4">
               <img id="file-ip-4-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
               <button type="button" class="imgRemove" onclick="myImgRemove(4)"></button>
             </label>
             <input type="file" name="image[]" id="file-ip-4" accept="image/*" onchange="showPreview(event, 4);">
           </div>
         </div><!-- single-upload end -->
         <div class="single-upload">
           <div class="form-input">
             <label for="file-ip-5">
               <img id="file-ip-5-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
               <button type="button" class="imgRemove" onclick="myImgRemove(5)"></button>
             </label>
             <input type="file" name="image[]" id="file-ip-5" accept="image/*" onchange="showPreview(event, 5);">
           </div>
         </div><!-- single-upload end -->
         <div class="single-upload">
           <div class="form-input">
             <label for="file-ip-6">
               <img id="file-ip-6-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
               <button type="button" class="imgRemove" onclick="myImgRemove(6)"></button>
             </label>
             <input type="file" name="image[]" id="file-ip-6" accept="image/*" onchange="showPreview(event, 6);">
           </div>
         </div><!-- single-upload end -->
       </div>

        <div class="col-lg-12 form-group">
          <label><?php echo app('translator')->get('Title'); ?></label>
          <input type="text" name="title" placeholder="<?php echo app('translator')->get('Enter title'); ?>" class="form--control" required value="<?php echo e(old('title')); ?>">
        </div>

        <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Condition'); ?></label>
          <select class="form--control" name="condition" required>
            <option value="2"><?php echo app('translator')->get('Used'); ?></option>
            <option value="1"><?php echo app('translator')->get('New'); ?></option>
          </select>
        </div>

        <div class="col-lg-12 form-group">
          <label><?php echo app('translator')->get('Description'); ?></label>
          <textarea name="description" placeholder="Description" class="form--control nicEdit"><?php echo e(old('description')); ?></textarea>
        </div>

        <?php if($subcategory->fields->count() > 0): ?>
        <input type="hidden" name="">
           <?php $__currentLoopData = $subcategory->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($field->type == 1 || $field->type == 4 ): ?>
                  <div class="form-group col-lg-12">
                      <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'Required'); ?>)</small> </label>
                      <?php if($field->type == 1): ?>
                          <input class="form--control" name="<?php echo e($field->name); ?>" type="text" placeholder="<?php echo e(__($field->placeholder)); ?>" <?php echo e($field->required == 1 ? 'required':''); ?> value="">
                      <?php else: ?>
                        <textarea class="form--control" name="<?php echo e($field->name); ?>"  placeholder="<?php echo e(__($field->placeholder)); ?>" <?php echo e($field->required == 1 ? 'required':''); ?>><?php echo e(old('extraField')); ?></textarea>
                      <?php endif; ?>
                  </div>

              <?php elseif($field->type == 2 || $field->type == 3): ?>
                  <div class="form-group col-lg-12">
                      <?php if($field->type == 2 ): ?>
                      <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'Required'); ?>)</small></label>
                      <select class="form--control" <?php echo e($field->required == 1 ? 'required':''); ?> name="<?php echo e($field->name); ?>[]">
                          <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option><?php echo e($opt); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php else: ?>
                          <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'At least 1 field required'); ?>)</small></label>
                          <div class="row">
                            <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="<?php echo e($field->name); ?>[]" value="<?php echo e($opt); ?>" id="customCheck<?php echo e($loop->iteration); ?>">
                                <label class="custom-control-label" for="customCheck<?php echo e($loop->iteration); ?>"><?php echo app('translator')->get($opt); ?></label>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                      <?php endif; ?>

                  </div>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


       <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Pice'); ?></label>
           <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><?php echo e($general->cur_sym); ?></span>
            <input type="text" class="form--control" name="price" placeholder="<?php echo app('translator')->get('Enter price'); ?>">
            <span class="input-group-text" id="basic-addon1">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" name="negotiable" id="customCheck31" >
                <label class="custom-control-label" for="customCheck31"><?php echo app('translator')->get('Negotiable'); ?></label>
              </div>
            </span>
          </div>
        </div>

        <div class="col-md-12 form-group">
            <label><?php echo app('translator')->get('Item Ownership'); ?></label>
            <select class="form--control" name="Ownership" required>
              <option value="Owner"><?php echo app('translator')->get('Owner'); ?></option>
              <option value="Broker"><?php echo app('translator')->get('Broker'); ?></option>
            </select>
          </div>

      </div><!-- row end -->

      <h4 class="title mt-4"><?php echo app('translator')->get('Contact Details'); ?></h4>
      <div class="row">
        <div class="col-md-6 form-group">
          <label><?php echo app('translator')->get('Name'); ?></label>
          <input type="text"  value="<?php echo e(auth()->user()->fullname); ?>" class="form--control" readonly>
        </div>
        <div class="col-md-6 form-group">
          <label><?php echo app('translator')->get('Email'); ?></label>
          <input type="email"  value="<?php echo e(auth()->user()->email); ?>" class="form--control" readonly>
        </div>
        <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Phone Number'); ?></label>
          <div class="input-group">
            <span class="input-group-text">
              <div class="custom-control custom-checkbox form-check-primary d-flex align-items-center">
                <input type="checkbox" class="custom-control-input" name="hidenumber" id="customCheck32" >
                <label class="custom-control-label" for="customCheck32"><?php echo app('translator')->get('Hide Number'); ?></label>
              </div>
            </span>
            <input type="tel" name="phone" placeholder="<?php echo app('translator')->get('Enter phone number'); ?>" class="form--control" value="<?php echo e(auth()->user()->mobile); ?>" required>
          </div>
        </div>
      </div><!-- row end -->
      <div class="mt-3">
        <button type="submit" class="btn btn--base btn-md w-100"><?php echo app('translator')->get('Post Your Ad'); ?></button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>

 <script>
        'use strict';
            var number = 1;
            do {
             var showPreview =  function showPreview(event, number){
                if(event.target.files.length > 0){
                  let src = URL.createObjectURL(event.target.files[0]);
                  let preview = document.getElementById("file-ip-"+number+"-preview");
                  preview.src = src;
                  preview.style.display = "block";
                }
              }
              var myImgRemove =  function myImgRemove(number) {
                  document.getElementById("file-ip-"+number+"-preview").src = "<?php echo e(getImage('assets/images/default.png')); ?>";
                  document.getElementById("file-ip-"+number).value = null;
                }
              number++;
            }
            while (number < 6);
 </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/user/ads/postAdForm.blade.php ENDPATH**/ ?>