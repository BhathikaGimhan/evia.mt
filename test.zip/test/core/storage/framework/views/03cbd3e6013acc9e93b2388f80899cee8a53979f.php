

<?php $__env->startSection('content'); ?>
<section class="pt-50 pb-50">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <ul class="page-link-inline-menu">
            <li><?php echo app('translator')->get('Home'); ?></li>
            <li><?php echo app('translator')->get('All ads'); ?></li>
            <li><?php echo e($ad->division); ?></li>
            <li><?php echo e($ad->district); ?></li>
            <li><?php echo e($ad->subcategory->category->name); ?></li>
            <li><?php echo e($ad->subcategory->name); ?></li>
          </ul>
        </div>
      </div>
      <div class="category-details-wrapper">
        <div class="row mb-4">
          <div class="col-lg-8">
            <h3 class="ad-details-title mb-2"><?php echo e(__($ad->title)); ?></h3>
            <ul class="meta-list">
              <li>
                <i class="las la-clock"></i>
                <span><?php echo e(diffForHumans($ad->created_at)); ?></span>
              </li>
              <li>
                <i class="las la-user"></i>
                <a href="javascript:void(0)"><?php echo e($ad->user->fullname); ?></a>
              </li>
              <li>
                <i class="las la-map-marker"></i>
                <span><?php echo e($ad->district); ?>, <?php echo e($ad->division); ?></span>
              </li>
            </ul>
          </div>
          <div class="col-md-5 mt-md-0 mt-3">
          </div>
        </div>
        <div class="row justify-content-between">
          <div class="col-lg-8">
            <div class="ad-details-content-wrapper">
              <div class="ad-details-thumb-area">
                <h5 class="ad-details-price"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($ad->price)); ?></h5>
                <div class="main-thumb-slider">
                  <?php $__currentLoopData = $ad->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="main-thumb">
                        <img src="<?php echo e(getImage('assets/images/item_image/'.$image->image,'200x200')); ?>" alt="image">
                        <a href="<?php echo e(getImage('assets/images/item_image/'.$image->image,'200x200')); ?>" class="fullview-image" data-rel="lightcase:myCollection:slideshow"></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- main-thumb-slider end -->
                <div class="ad-details-nav-slider mt-4">
                    <?php $__currentLoopData = $ad->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="ad-details-nav-thumb">
                        <img src="<?php echo e(getImage('assets/images/item_image/'.$image->image,'200x200')); ?>" alt="image">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!-- ad-details-nav-slider end -->
              </div>
             
              <div class="ad-details-content">
                <h4><?php echo app('translator')->get('Ad Overview'); ?></h4>
                <ul class="caption-list-two mt-3">
                  <li>
                    <span class="caption"><?php echo app('translator')->get('Condition'); ?></span>
                    <span class="value"><?php echo e($ad->use_condition == 1 ? 'New':'Used'); ?></span>
                  </li>
                  <li>
                    <span class="caption"><?php echo app('translator')->get('Type'); ?></span>
                    <span class="value"><?php echo e($ad->type == 1 ? 'Sell':'Rent'); ?></span>
                  </li>
                 
                  <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_array($field)): ?>
                       <li>
                           <span class="caption"><?php echo e(__(ucwords(str_replace('_',' ',$key)))); ?></span>
                            <span class="value">
                                <?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item); ?> <?php if(!$loop->last): ?> ,<?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </li>
                    <?php else: ?>
                        <li>
                            <span class="caption"><?php echo e(__(ucwords(str_replace('_',' ',$key)))); ?></span>
                            <span class="value"><?php echo e($field); ?></span>
                        </li>
                    <?php endif; ?>
                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
             

                <h4 class="mt-5"><?php echo app('translator')->get('Description'); ?></h4>
                <p class="mt-2">
                  <?php
                      echo $ad->description;
                  ?>
                </p>
                <hr>

              </div>
            
              <button class="ad-details-show-btn mt-3">
                <span class="text-one"><?php echo app('translator')->get('Show Details'); ?></span>
                <span class="text-two"><?php echo app('translator')->get('Show Less'); ?></span>
              </button>

            </div>

            <div class="my-5 text-center">
              <?php
                    echo advertisements('970x90');
              ?>

            </div>

            <?php if($ad->relatedProducts()->count() > 1): ?>
            <h4 class="mt-5"><?php echo app('translator')->get('Related Ads'); ?></h4>
            <div class="related-ad-slider mt-3">
              <?php $__empty_1 = true; $__currentLoopData = $ad->relatedProducts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <?php
                      $slug = $item->subcategory->slug;
                  ?>
                <?php if($item->id != $ad->id): ?>
                <div class="single-slide">
                  <div class="list-item related--ad">
                    <div class="list-item__thumb">
                      <a href="<?php echo e(route('ad.details',$item->slug)); ?>"><img src="<?php echo e(getImage('assets/images/item_image/'.$item->prev_image,'256x230')); ?>" alt="image"></a>
                    </div>
                    <div class="list-item__wrapper">
                      <div class="list-item__content">
                        <a class="cat-title" href="<?php echo e(url('/ads/')."/$slug"."?location=".request()->input('location')); ?>" class="category"><i class="las la-tag"></i> <?php echo e(__($item->subcategory->name)); ?></a>
                        <h6 class="title" data-toggle="tooltip" title="<?php echo e(__($item->title)); ?>"><a  href="<?php echo e(route('ad.details',$item->slug)); ?>"><?php echo e(__($item->title)); ?></a></h6>
                      </div>
                      <div class="list-item__footer mt-2">
                        <div class="price"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->price)); ?></div>
                      </div>
                    </div>
                  </div><!-- list-item end -->
                </div><!-- single-slide end -->
                <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h6 class="mt-5"><?php echo app('translator')->get('No Related Ads'); ?></h6>
              <?php endif; ?>
             
            </div>
            <?php endif; ?>
          </div>
          <div class="col-lg-4 col-xxl-3 mt-lg-0 mt-5">
            <div class="ad-details-sidebar">
              <div class="ad-save">
                <?php if(auth()->guard()->check()): ?>
                <div class="mb-4">
                    <?php if(auth()->id() != $ad->user_id): ?>
                      <?php if( !auth()->user()->userFavourite($ad->id)): ?>
                        <button type="button" data-userid="<?php echo e(auth()->id()); ?>" data-adid="<?php echo e($ad->id); ?>" class="ad-save__btn save"><i class="las la-bookmark"></i> <?php echo app('translator')->get('Save Ad'); ?></button>
                      <?php else: ?>
                        <button type="button" class="ad-save__btn bg--base text-white"><i class="las la-check"></i> <?php echo app('translator')->get('Saved'); ?></button>
                      <?php endif; ?>
                    <?php endif; ?>
                  </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                <div class="mb-4">
                  <a href="<?php echo e(route('user.login')); ?>"  class="ad-save__btn text-dark"><i class="las la-bookmark"></i> <?php echo app('translator')->get('Save Ad'); ?></a>
                </div>
                <?php endif; ?>
              </div>

              <div class="ad-details-widget">
                <h6 class="ad-details-widget__title"><?php echo app('translator')->get('Seller Details'); ?></h6>
                <div class="ad-details-widget__body">
                  <ul class="user-info-list">
                    <li>
                      <div class="icon">
                        <i class="las la-user"></i>
                      </div>
                      <div class="content">
                        <span class="caption"><?php echo app('translator')->get('For sale by'); ?></span>
                        <h6 class="value"><?php echo e($ad->user->fullname); ?></h6>
                      </div>
                    </li>
                    <li>
                      <div class="icon">
                        <i class="las la-map-marker"></i>
                      </div>
                      <div class="content">
                        <span class="caption"><?php echo app('translator')->get('Location'); ?></span>
                        <h6 class="value"><?php echo e($ad->district); ?></h6>
                      </div>
                    </li>
                    <li class="has--link">
                      
                      <div class="icon">
                        <i class="las la-phone-volume"></i>
                      </div>

                      <?php if($ad->hide_contact == 1): ?>
                      <div class="content">
                        <a href="javascript:void(0)" class="btn btn-sm btn--dark show"><i class="las la-eye"></i> <?php echo app('translator')->get('Show Contact'); ?></a>
                        <span class="caption hide d-none"><?php echo app('translator')->get('Contact Number'); ?></span>
                        <h6 class="value hide-value d-none"><?php echo e($ad->contact_num); ?></h6>
                      </div>
                      <?php else: ?>
                      <div class="content">
                        <span class="caption"><?php echo app('translator')->get('Contact Number'); ?></span>
                        <h6 class="value"><?php echo e($ad->contact_num); ?></h6>
                      </div>
                      <?php endif; ?>
                    </li>
                    
                  </ul>
                </div>
              </div>
              

           

              <div class="ad-details-widget mt-4">
                <h6 class="ad-details-widget__title"><i class="las la-external-link-alt"></i> <?php echo app('translator')->get('Share'); ?></h6>
                <div class="ad-details-widget__body">
                    <ul class="post__share">
                      <li><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"><i class="lab la-facebook-f"></i></a></li>
                   
                      <li><a target="_blank" href="http://pinterest.com/pin/create/button/?url=<?php echo e(urlencode(url()->current())); ?>&description=<?php echo e(__($ad->title)); ?>&media=<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image)); ?>"><i class="lab la-pinterest"></i></a></li>
                     
                      <li><a target="_blank" href="https://twitter.com/intent/tweet?text=my share text&amp;url=<?php echo e(urlencode(url()->current())); ?>"><i class="lab la-twitter"></i></a></li>
                    </ul>
                </div>
              </div>




              <div class="ad-details-content-footer mt-4">
                <div class="left m-lg-0 m-2">

              <?php if($ad->featured == 1): ?>
                <a href="javascript:void(0)" class="btn btn-md btn--success w-100"><i class="las la-bullhorn"></i> <?php echo app('translator')->get('Featured'); ?></a>
              <?php elseif($ad->promoted()): ?>
                <a href="javascript:void(0)" class="btn btn-md btn--warning w-100"><i class="las la-bullhorn"></i> <?php echo app('translator')->get('Requested'); ?></a>
              <?php else: ?>
                <a href="<?php echo e(route('user.promote.ad.packages',$ad->slug)); ?>" class="btn btn-md btn--primary w-100"><i class="las la-bullhorn"></i> <?php echo app('translator')->get('Promote this ad'); ?></a>
              <?php endif; ?>
                
              </div>

              <?php if(auth()->guard()->check()): ?>
              <?php if($ad->user != auth()->user()): ?>
              <div class="right m-2 m-lg-0 mt-lg-3">
                      <?php if($ad->userReport(auth()->id())): ?>
                        <a href="javascript:void(0)"  class="btn btn-md btn--dark w-100"><i class="las la-flag"></i></i> <?php echo app('translator')->get('Reported'); ?></a>
                      <?php else: ?>
                        <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#adReportModal" class="btn btn-md btn--danger w-100"><i class="las la-flag"></i></i> <?php echo app('translator')->get('Report this ad'); ?></a>
                      <?php endif; ?>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <div class="right m-2 m-lg-0 mt-lg-3">
                  <a href="<?php echo e(route('user.login')); ?>" class="btn btn-md btn--danger w-100"><i class="las la-flag"></i></i> <?php echo app('translator')->get('Report this ad'); ?></a>
                </div>
                <?php endif; ?>
              </div>

              <div class="mt-4 text-center d-sm-none d-lg-block">
                <?php
                    echo advertisements('300x600');
                ?>
              </div>

              <div class="mt-4 text-center d-sm-none d-lg-block">
                <?php
                    echo advertisements('300x250');
                ?>
              </div>
              <div class="d-none d-sm-block d-lg-none mt-4 text-center">
                <?php
                    echo advertisements('970x90');
                ?>
              </div>
            </div><!-- ad-details-sidebar end -->
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset($activeTemplateTrue.'js/axios.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<script>
  'use strict';
    $('.show').on('click',function () { 
        $(this).addClass('d-none')
        $('.hide').removeClass('d-none')
        $('.hide-value').removeClass('d-none')
    })

    $('.save').on('click',function () { 
        var userid = $(this).data('userid')
        var adId = $(this).data('adid')
       
        var data = {
          userid:userid,
          adId:adId
        }
        var route = "<?php echo e(route('user.save.ad')); ?>"
        axios.post(route,data).then(function (res) { 
          if(res.data.adId ||res.data.userid)
          {
            $.each(res.data, function (i, val) { 
               notify('error',val)
            });
          } else{
            notify('success',res.data.success)
          }
          
        })
     })
    $('.advert').on('click',function () { 
        var ad_id = $(this).data('advertid')
        var data = {
          ad_id:ad_id
        }
        var route = "<?php echo e(route('ad.click')); ?>"
        axios.post(route,data).then(function (res) { })
     })
</script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('additionalSeo'); ?>
  <?php if ($__env->exists($activeTemplate.'partials.additionalSeo',['ad'=>$ad])) echo $__env->make($activeTemplate.'partials.additionalSeo',['ad'=>$ad], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/adDetails.blade.php ENDPATH**/ ?>