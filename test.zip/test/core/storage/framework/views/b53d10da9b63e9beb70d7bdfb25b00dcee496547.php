
<?php $__env->startSection('content'); ?>
<section class="pt-50 pb-50">
    <div class="container py-xl-5">
        <div class="text-center mb-30-none d-flex flex-wrap justify-content-center">
           <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="plan shadow">
            <div class="plan-inner">
              <div class="entry-title">
                <h3 class="shadow-sm"><?php echo e(__( $pkg->name)); ?></h3>
                 <div class="price"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($pkg->price)); ?>

                </div>
              </div>
              <div class="entry-content">
                <ul>
                  <li><strong><?php echo app('translator')->get('Validity'); ?></strong> <?php echo e($pkg->validity); ?> <?php echo app('translator')->get('days'); ?></li>
                </ul>
              </div>
              <div class="btn">
                <a href="javascript:void(0)" data-balance="<?php echo e(route('user.payment.promote',[$ad->id,$pkg->id])); ?>" data-gateway="<?php echo e(route('user.deposit',[$ad->id,$pkg->id])); ?>" data-price="<?php echo e(getAmount($pkg->price)); ?>" class="btn--base shadow-sm purchase"><?php echo app('translator')->get('Promote Now'); ?></a>
              </div>
            </div>
          </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script>
      'use strict';
      $('.purchase').on('click',function(){
        var gatewayRoute = $(this).data('gateway')
        var balanceRoute = $(this).data('balance')
        var price = $(this).data('price')
        var curr = "<?php echo e($general->cur_text); ?>"
         
        var modal = $('#purchaseModal');
        $('.packagePrice').text(price+' '+curr)
        $('.gateway').attr('href',gatewayRoute)
        $('.promotionBalance').attr('href',balanceRoute)
        modal.modal('show');
    })
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/packages.blade.php ENDPATH**/ ?>