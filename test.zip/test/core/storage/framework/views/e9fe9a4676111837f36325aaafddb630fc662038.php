<?php if(Route::currentRouteName()=='ticket.view'): ?>
<div class="modal fade" id="DelModal" tabindex="-1" role="dialog"  aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" action="<?php echo e(route('ticket.reply', $my_ticket->id)); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header bg--sec">
                    <h5 class="modal-title text-white"> <?php echo app('translator')->get('Confirmation'); ?>!</h5>
                    <button type="button" class="btn-close close-button" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <strong class="text-dark"><?php echo app('translator')->get('Are you sure you want to Close This Support Ticket'); ?>?</strong>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark btn-sm" data-bs-dismiss="modal"><i class="fa fa-times"></i>
                        <?php echo app('translator')->get('Close'); ?>
                    </button>
                    <button type="submit" class="btn btn--success btn-sm" name="replayTicket" value="2"><i class="fa fa-check"></i> <?php echo app('translator')->get("Confirm"); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/partials/ticketCloseModal.blade.php ENDPATH**/ ?>