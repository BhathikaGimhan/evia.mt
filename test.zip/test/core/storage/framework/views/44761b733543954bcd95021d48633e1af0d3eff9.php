
<?php $__env->startSection('content'); ?>
<div class="create-ad-wrapper">
    <form action="<?php echo e(route('user.ad.update',$ad->id)); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
    
     <div class="d-flex justify-content-between title">
       <h4 class=""><?php echo app('translator')->get('Ad Information'); ?></h4>
        <div class=""> 
          <small class="font-weight-bold h6"> <i class="las la-tag text--base"></i> <?php echo e($ad->subcategory->name); ?></small>
          <small class="font-weight-bold h6"> <i class="las la-map-marker text--base"></i> <?php echo e($ad->district); ?></small>
        </div>
     </div>
      <div class="row">
        <label class="mb-3 font-weight-bold"><?php echo app('translator')->get('Item Images'); ?></label>
        <div class="product-image-upload-container mb-2 d-flex justify-content-center">
          <div class="single-upload">
            <div class="center" >
              <div class="form-input">
                <label for="file-ip-0" data-toggle="tooltip" title="<?php echo app('translator')->get('Preview image'); ?>">
                  <img id="file-ip-0-preview" src="<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image)); ?>">
                  <button type="button" class="imgRemove" onclick="myImgRemove(0)"></button>
                </label>
                <input type="file"  name="prev_image" id="file-ip-0" accept="image/*" onchange="showPreview(event, 0);">
              </div>
            </div>
          </div>
          <?php $__currentLoopData = $ad->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="single-upload">
            <div class="center">
              <div class="form-input">
                <label for="file-ip-<?php echo e($loop->iteration); ?>">
                  <img id="file-ip-<?php echo e($loop->iteration); ?>-preview" src="<?php echo e(getImage('assets/images/item_image/'.$img->image)); ?>">
                  <button type="button" class="imgRemove imgDelete" data-bs-toggle="modal" data-bs-target="#imageRemoveModal" data-action="<?php echo e(route('user.ad.image.remove',$img->id)); ?>"></button>
                </label>
                <input type="file"  name="image[<?php echo e($img->id); ?>]" id="file-ip-<?php echo e($loop->iteration); ?>" accept="image/*" onchange="showPreview(event, <?php echo e($loop->iteration); ?>);">
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php
            $count = $ad->images->count();
            $remaining = 5 - $count;
          ?>

          <?php for($i = 0; $i < $remaining; $i++): ?>
          <div class="single-upload">
            <div class="center">
              <div class="form-input">
                <label for="file-ip-<?php echo e($i+10); ?>">
                  <img id="file-ip-<?php echo e($i+10); ?>-preview" src="<?php echo e(getImage('assets/images/default.png')); ?>">
                  <button type="button" class="imgRemove" onclick="myImgRemove(<?php echo e($i+10); ?>)"></button>
                </label>
                <input type="file"  name="image[]" id="file-ip-<?php echo e($i+10); ?>" accept="image/*" onchange="showPreview(event, <?php echo e($i+10); ?>);">
              </div>
            </div>
          </div>
          <?php endfor; ?>
         
        </div>
   
      
  
        <div class="col-lg-12 form-group">
          <label><?php echo app('translator')->get('Title'); ?></label>
          <input type="text" name="title" placeholder="<?php echo app('translator')->get('Enter title'); ?>" class="form--control" required value="<?php echo e($ad->title); ?>">
        </div>
        
        <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Condition'); ?></label>
          <select class="form--control" name="condition" required>
            <option value="2" <?php echo e($ad->use_condition == 2?'selected':''); ?>><?php echo app('translator')->get('Used'); ?></option>
            <option value="1" <?php echo e($ad->use_condition == 1?'selected':''); ?>><?php echo app('translator')->get('New'); ?></option>
          </select>
        </div>
       
        <div class="col-lg-12 form-group">
          <label><?php echo app('translator')->get('Description'); ?></label>
          <textarea name="description" placeholder="Description" class="form--control nicEdit" required ><?php echo e($ad->description); ?></textarea>
        </div>
        
        <?php if($ad->subcategory->fields->count() > 0): ?>
           <?php $__currentLoopData = $ad->subcategory->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($field->type == 1 || $field->type == 4 ): ?>
                  <div class="form-group col-lg-12">
                      <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'Required'); ?>)</small> </label>
                      <?php if($field->type == 1): ?>
                          <input class="form--control" name="<?php echo e($field->name); ?>" type="text" placeholder="<?php echo e(__($field->placeholder)); ?>" <?php echo e($field->required == 1 ? 'required':''); ?> value="<?php echo e(!empty($adFields[$field->name])?$adFields[$field->name]:''); ?>">
                      <?php else: ?>
                        <textarea class="form--control" name="<?php echo e($field->name); ?>"  placeholder="<?php echo e(__($field->placeholder)); ?>" <?php echo e($field->required == 1 ? 'required':''); ?>><?php echo e(!empty($adFields[$field->name])?$adFields[$field->name]:''); ?></textarea>
                      <?php endif; ?>
                  </div>

              <?php elseif($field->type == 2 || $field->type == 3): ?>
              <div class="form-group col-lg-12">
                <?php if($field->type == 2 ): ?>
                  <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'Required'); ?>)</small></label>
                     <select class="form--control" <?php echo e($field->required == 1 ? 'required':''); ?> name="<?php echo e($field->name); ?>[]">
                        <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option <?php echo e(!empty($adFields[$field->name]) && $adFields[$field->name][0] == $opt?'selected':''); ?>><?php echo e($opt); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php else: ?>
                          <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> <small>(<?php echo e($field->required != 1 ? 'Optional':'At least 1 field is required'); ?>)</small></label>
                          <div class="row">
                            <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           
                            <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6">
                              <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="" name="<?php echo e($field->name); ?>[]" id="customCheck<?php echo e($loop->iteration); ?>"  <?php echo e(!empty($adFields[$field->name]) && in_array($opt,$adFields[$field->name])?'checked':''); ?> value="<?php echo e($opt); ?>">
                                <label class="custom-control-label" for="customCheck<?php echo e($loop->iteration); ?>"><?php echo app('translator')->get($opt); ?></label>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                      <?php endif; ?>
                  </div>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        

       <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Pice'); ?></label>
           <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><?php echo e($general->cur_sym); ?></span>
            <input type="text" class="form--control" name="price" placeholder="<?php echo app('translator')->get('Enter price'); ?>" value="<?php echo e(getAmount($ad->price)); ?>">
            <span class="input-group-text" id="basic-addon1">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" class="" name="negotiable" id="customCheck101
                "  <?php echo e($ad->negotiable == 1?'checked':''); ?>>
                <label class="custom-control-label" for="customCheck101"><?php echo app('translator')->get('Negotiable'); ?></label>
              </div>
      
            </span>
          </div>
        </div>
        
      </div><!-- row end -->

      <h4 class="title mt-4"><?php echo app('translator')->get('Contact Details'); ?></h4>
      <div class="row">
        <div class="col-md-6 form-group">
          <label><?php echo app('translator')->get('Name'); ?></label>
          <input type="text"  value="<?php echo e(auth()->user()->fullname); ?>" class="form--control" readonly>
        </div>
        <div class="col-md-6 form-group">
          <label><?php echo app('translator')->get('Email'); ?></label>
          <input type="email"  value="<?php echo e(auth()->user()->email); ?>" class="form--control" readonly>
        </div>
        <div class="col-md-12 form-group">
          <label><?php echo app('translator')->get('Phone Number'); ?></label>
        
          <div class="input-group">
            <span class="input-group-text d-flex align-items-center">
              <div class="custom-control custom-checkbox">
                <input type="checkbox" name="hidenumber" id="customCheck201" <?php echo e($ad->hide_contact == 1?'checked':''); ?>>
                <label class="custom-control-label" for="customCheck201"><?php echo app('translator')->get('Hide Number'); ?></label>
              </div>
            </span>
            <input type="tel" name="phone" placeholder="<?php echo app('translator')->get('Enter phone number'); ?>" class="form--control" value="<?php echo e($ad->contact_num); ?>" required>
          </div>
        </div>
      </div><!-- row end -->
      <div class="mt-3">
        <button type="submit" class="btn btn--base btn-md w-100"><?php echo app('translator')->get('Update Ad'); ?></button>
      </div>
    </form>
  </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>

 <script>
        'use strict';
            var number = 1;
            do {
             var showPreview =  function showPreview(event, number){
                if(event.target.files.length > 0){
                  let src = URL.createObjectURL(event.target.files[0]);
                  let preview = document.getElementById("file-ip-"+number+"-preview");
                  preview.src = src;
                  preview.style.display = "block";
                } 
              }
              var myImgRemove =  function myImgRemove(number) {
                  document.getElementById("file-ip-"+number+"-preview").src = "<?php echo e(getImage('assets/images/default.png')); ?>";
                  document.getElementById("file-ip-"+number).value = null;
                }
              number++;
            }
            while (number < 6);

            $('.imgDelete').click(function(){
              var modal = $('#imageRemoveModal');
              modal.find('form').attr('action',$(this).data('action'))
            })
 </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/user/ads/editAd.blade.php ENDPATH**/ ?>