
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 d-flex justify-content-end">
    <form action="">
       <div class="input-group">
         <input class="form-control outline-0 shadow-none" value="<?php echo e($search??''); ?>" type="text" name="search" placeholder="<?php echo app('translator')->get('Search by title'); ?>" required>
          <button type="submit" class="input-group-text bg--sec"><i class="las la-search"></i></button>
       </div>
    </form>
  </div>
  
    <div class="col-lg-12">
      <div class="table-responsive--md">
        <table class="table custom--table">
          <thead>
            <tr>
              <th><?php echo app('translator')->get('Ad title'); ?></th>
              <th><?php echo app('translator')->get('Date'); ?></th>
              <th><?php echo app('translator')->get('Status'); ?></th>
              <th><?php echo app('translator')->get('Action'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $favourites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-label="<?php echo app('translator')->get('Ad title'); ?>">
                  <div class="table-item">
                    <div class="thumb">
                      <img src="<?php echo e(getImage('assets/images/item_image/'.$fav->ad->prev_image,'200x200')); ?>" alt="image">
                    </div>
                    <div class="content">
                      <h6 class="title"><a target="_blank" href="<?php echo e(route('ad.details',$fav->ad->slug)); ?>"><?php echo e($fav->ad->title); ?></a></h6>
                    </div>
                  </div>
                </td>
                <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($fav->created_at,'d M Y')); ?></td>
                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                    <?php if($fav->ad->status == 1): ?>
                    <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                    <?php else: ?>
                    <span class="badge badge--warning"><?php echo app('translator')->get('Inactive'); ?></span>
                    <?php endif; ?>
                </td>
                <td data-label="Action">
                  <a href="<?php echo e(route('user.unsave.ad',$fav->id)); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('Unsave'); ?>" class="icon-btn btn-danger"><i class="las la-trash-alt"></i></a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td colspan="12" class="text-center"><?php echo app('translator')->get('No Saved Ads'); ?></td></tr>
            <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </div>
    <?php echo e(paginateLinks($favourites,'partials.paginate')); ?>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/ads/saved.blade.php ENDPATH**/ ?>