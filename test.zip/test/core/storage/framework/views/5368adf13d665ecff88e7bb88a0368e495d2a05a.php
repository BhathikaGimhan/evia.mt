
<?php $__env->startSection('content'); ?>
<section class="pt-100 pb-100">
    <div class="container">
      <div class="row gy-4 justify-content-center pb-50">
        <div class="col-xl-12">
          <div class="p-3 p-sm-4 p-md-5 rounded section-bg">
                <div class="faq-wrapper style-two">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <div class="faq-item">
                        <div class="faq-title">
                            <h6 class="title"><?php echo e(__($faq->data_values->question)); ?></h6>
                            <div class="right-icon"></div>
                        </div>
                        <div class="faq-content">
                            <p>
                               <?php
                                   echo $faq->data_values->answer;
                               ?>
                            </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<style>
    .faq-content{
        display: none;
    }
</style>

<?php $__env->stopPush(); ?>
<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/faq.blade.php ENDPATH**/ ?>