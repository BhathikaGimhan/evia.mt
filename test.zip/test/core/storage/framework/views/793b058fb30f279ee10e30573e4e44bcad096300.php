<?php if(Route::currentRouteName() == 'user.twofactor'): ?>
    
    <div id="enableModal" class="modal fade" role="dialog">
        <div class="modal-dialog ">
            <!-- Modal content-->
            <div class="modal-content ">
                <div class="modal-header bg--sec">
                    <h4 class="modal-title text-white"><?php echo app('translator')->get('Verify Your Otp'); ?></h4>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="modal"></button>
                </div>
                <form action="<?php echo e(route('user.twofactor.enable')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body ">
                        <div class="form-group">
                            <input type="hidden" name="key" value="<?php echo e($secret); ?>">
                            <input type="text" class="form-control" name="code" placeholder="<?php echo app('translator')->get('Enter Google Authenticator Code'); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark btn-sm" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--primary btn-sm"><?php echo app('translator')->get('Verify'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

  <!--Disable Modal -->
  <div id="disableModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header bg--sec">
                <h4 class="modal-title text-white"><?php echo app('translator')->get('Verify Your Otp Disable'); ?></h4>
                <button type="button" class="btn-close text-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('user.twofactor.disable')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" name="code" placeholder="<?php echo app('translator')->get('Enter Google Authenticator Code'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark btn-sm" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                    <button type="submit" class="btn btn--primary btn-sm"><?php echo app('translator')->get('Verify'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/twofactorModal.blade.php ENDPATH**/ ?>