<?php $__env->startSection('content'); ?>
<?php
    $login = getContent('login.content',true)->data_values;
?>
<section class="pt-100 pb-100">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-9">
          <div class="account-wrapper">
            <div class="left bg_img" style="background-image: url(<?php echo e(getImage('assets/images/frontend/login/'.$login->background_image,'1080x700')); ?>);">
                <div>
                    <h3 class="mb-3 text-white"><?php echo app('translator')->get('Reset Password'); ?></h3>
                </div>
            </div>
            <div class="right">
              <h3 class="title"><?php echo app('translator')->get('Reset Your Password'); ?></h3>
              <form method="POST" action="<?php echo e(route('user.password.email')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label><?php echo app('translator')->get('My'); ?></label>
                    <select class="form--control" name="type">
                        <option value="email"><?php echo app('translator')->get('E-Mail Address'); ?></option>
                        <option value="username"><?php echo app('translator')->get('Username'); ?></option>
                    </select>
                </div>
                <div class="form-group">
                  <label class="my_value"></label>
                  <input type="text"name="value" value="<?php echo e(old('value')); ?>" class="form--control" required>
                </div>
               
                <div class="form-group">
                  <button type="submit" class="btn btn--base btn-md w-100"><?php echo app('translator')->get('Send Reset Code'); ?></button>
                </div>
               
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    'use strict'
    $('select[name=type]').on('change',function(){
        $('.my_value').text($('select[name=type] :selected').text());
    }).change();
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('templates.basic.layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/user/auth/passwords/email.blade.php ENDPATH**/ ?>