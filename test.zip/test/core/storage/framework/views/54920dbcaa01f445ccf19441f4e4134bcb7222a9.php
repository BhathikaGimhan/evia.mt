
 <?php if(@$categories && @$divisions): ?>
      <!-- Select Location Modal -->
  <div class="modal fade" id="locationModal" tabindex="-1" aria-labelledby="locationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="locationModalLabel"><?php echo app('translator')->get('Select Location'); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="select-menu-list">
            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="has-drop-menu">
              <a href="javascript:void(0)">
                <img src="<?php echo e(getImage('assets/images/location/'.$division->image,'100x100')); ?>" alt="image" class="select-menu-img">
                <span><?php echo e($division->name); ?></span>
              </a>
              <ul class="drop-menu">
                  <?php $__currentLoopData = $division->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <li>
                    <a href="<?php echo e(queryBuild('location',$district->slug)); ?>">
                      <i class="las la-map-marker"></i>
                      <span><?php echo e(__($district->name)); ?></span>
                    </a>
                  </li>
               
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm btn--dark" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
        </div>
      </div>
    </div>
  </div>


  <!-- Select Category Modal -->
  <div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="categoryModalLabel"><?php echo app('translator')->get('Select Category'); ?></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="select-menu-list">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <li class="has-drop-menu">
              <a href="javascript:void(0)">
                <img src="<?php echo e(getImage('assets/images/category/'.$cat->image)); ?>" alt="image" class="select-menu-img">
                <span><?php echo e(__($cat->name)); ?></span>
              </a>
              <ul class="drop-menu">
                <?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if(!empty(request()->input())): ?>
                 <li>
                  <a href="<?php echo e(url('/items/')."/$subcat->slug"."?location=".request()->input('location')); ?>">
                    <i class="las la-caret-right"></i>
                    <span><?php echo e($subcat->name); ?></span>
                  </a>
                </li>
                 <?php else: ?>
                 <li>
                  <a href="<?php echo e(url('/items/')."/$subcat->slug"); ?>">
                    <i class="las la-caret-right"></i>
                    <span><?php echo e($subcat->name); ?></span>
                  </a>
                  </li>
                 <?php endif; ?>
                 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </ul>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-sm btn--dark" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
        </div>
      </div>
    </div>
  </div>
 <?php endif; ?>
<?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/filterModals.blade.php ENDPATH**/ ?>