<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12">
          <div class="card shadow border-0">
            <div class="card-body d-flex justify-content-between">
                <h5 class="mt-2"><?php echo app('translator')->get('My Tickets'); ?></h5>
                <a class="btn btn--base btn-sm" href="<?php echo e(route('ticket.open')); ?>"> <i class="las la-plus"></i> <?php echo app('translator')->get('New Ticket'); ?></a>
            </div>
          </div>
          <div class="table-responsive--md">
            <table class="table custom--table">
              <thead>
                <tr>
                    <th scope="col"><?php echo app('translator')->get('Subject'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Last Reply'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td data-label="<?php echo app('translator')->get('Subject'); ?>"> <a href="<?php echo e(route('ticket.view', $support->ticket)); ?>" class="font-weight-bold"> [Ticket#<?php echo e($support->ticket); ?>] <?php echo e(__($support->subject)); ?> </a></td>
                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                        <?php if($support->status == 0): ?>
                            <span class="badge badge--success py-2 px-3"><?php echo app('translator')->get('Open'); ?></span>
                        <?php elseif($support->status == 1): ?>
                            <span class="badge badge--primary py-2 px-3"><?php echo app('translator')->get('Answered'); ?></span>
                        <?php elseif($support->status == 2): ?>
                            <span class="badge badge--warning py-2 px-3"><?php echo app('translator')->get('Customer Reply'); ?></span>
                        <?php elseif($support->status == 3): ?>
                            <span class="badge badge--dark py-2 px-3"><?php echo app('translator')->get('Closed'); ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?php echo app('translator')->get('Last Reply'); ?>"><?php echo e(\Carbon\Carbon::parse($support->last_reply)->diffForHumans()); ?> </td>

                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                        <a href="<?php echo e(route('ticket.view', $support->ticket)); ?>" class="icon-btn btn--primary">
                            <i class="fa fa-desktop"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e(paginateLinks($supports)); ?>

          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/support/index.blade.php ENDPATH**/ ?>