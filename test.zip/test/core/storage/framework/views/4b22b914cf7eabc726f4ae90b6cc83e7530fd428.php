<?php if(Route::currentRouteName() == 'ad.details'): ?>
<div class="modal fade" id="adReportModal" tabindex="-1" aria-labelledby="adReportModal" aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('user.report.ad')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="ad_id" value="<?php echo e($ad->id); ?>">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="locationModalLabel"><?php echo app('translator')->get('Tell Us The Reasons'); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label><?php echo app('translator')->get('Reasons'); ?></label>
                        <textarea class="form--control" name="reasons" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-sm btn--dark" data-bs-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                <button type="submit" class="btn btn-sm btn--primary"><?php echo app('translator')->get('Submit'); ?></button>
                </div>
            </div>
        </form>
    </div>
  </div>
<?php endif; ?>


<?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/adReportModal.blade.php ENDPATH**/ ?>