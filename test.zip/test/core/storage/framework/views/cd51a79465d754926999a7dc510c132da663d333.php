<?php $__currentLoopData = $featuredAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
  $slug = $item->subcategory->slug;
?>
 <div class="list-item list-item-featured list--style">
    <div class="list-item__thumb">
      <span class="featured--ticky"><?php echo app('translator')->get('Featured'); ?></span>
      <a href="<?php echo e(route('ad.details',$item->slug)); ?>"><img src="<?php echo e(getImage('assets/images/item_image/'.$item->prev_image,'275x200')); ?>" alt="image"></a>
    </div>
    <div class="list-item__wrapper">
      <div class="list-item__content">
        <a href="<?php echo e(url('/ads/')."/$slug"."?location=".request()->input('location')); ?>" class="category text--base"><i class="las la-tag"></i> <?php echo e($item->subcategory->name); ?></a>
        <h6 class="title"><a href="<?php echo e(route('ad.details',$item->slug)); ?>"><?php echo e(__($item->title)); ?></a></h6>
        <ul class="list-item__meta mt-1">
          <li>
            <i class="las la-clock"></i>
            <span><?php echo e(diffForHumans($item->created_at)); ?></span>
          </li>
          <li>
            <i class="las la-user"></i>
            <a href="javascript:void(0)"><?php echo e($item->user->fullname); ?></a>
          </li>
          <li>
            <i class="las la-map-marker"></i>
            <span><?php echo e($item->district); ?>, <?php echo e($item->division); ?></span>
          </li>
        </ul>
      </div>
      <div class="list-item__footer">
        <div class="price"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->price)); ?></div>
        <a href="<?php echo e(route('ad.details',$item->slug)); ?>" class="btn btn-sm btn--base mt-2"><?php echo app('translator')->get('View Details'); ?></a>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 <?php $__env->startPush('style'); ?>
      
  <style>
    .list-item-featured{
        background-color: #002046;
      }
  </style>

  <?php $__env->stopPush(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/featuredList.blade.php ENDPATH**/ ?>