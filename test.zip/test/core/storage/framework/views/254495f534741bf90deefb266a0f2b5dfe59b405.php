<?php
    $bg = getContent('breadcrumb.content',true)->data_values;
?>
<section class="inner-hero bg_img" style="background-image: url(<?php echo e(getImage('assets/images/frontend/breadcrumb/'.$bg->background_image)); ?>);">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <h2 class="page-title text-center"><?php echo e(__($page_title)); ?></h2>
          <ul class="page-breadcrumb justify-content-center">
            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
            <li><?php echo e(__($page_title)); ?></li>
          </ul>
        </div>
      </div>
    </div>
  </section><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>