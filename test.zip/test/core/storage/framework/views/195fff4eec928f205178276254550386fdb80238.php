
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12 d-flex justify-content-end">
      <form action="">
         <div class="input-group">
           <input class="form-control outline-0 shadow-none" value="<?php echo e($search??''); ?>" type="text" name="search" placeholder="<?php echo app('translator')->get('Search by title'); ?>" required>
            <button type="submit" class="input-group-text bg--sec"><i class="las la-search"></i></button>
         </div>
      </form>
  </div>
    <div class="col-lg-12">
      <div class="table-responsive--md">
        <table class="table custom--table">
          <thead>
            <tr>
              <th><?php echo app('translator')->get('Ad title'); ?></th>
              <th><?php echo app('translator')->get('Date'); ?></th>
              <th><?php echo app('translator')->get('Status'); ?></th>
              <th><?php echo app('translator')->get('Promote'); ?></th>
              <th><?php echo app('translator')->get('Action'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-label="<?php echo app('translator')->get('Ad title'); ?>">
                  <div class="table-item">
                    <div class="thumb">
                      <img src="<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image,'200x200')); ?>" alt="image">
                    </div>
                    <div class="content">
                      <h6 class="title"><a data-toggle="tooltip" title="<?php echo e(__($ad->title)); ?>" target="_blank" href="<?php echo e(route('ad.details',$ad->slug)); ?>"><?php echo e(shortDescription($ad->title,30)); ?></a></h6>
                    </div>
                  </div>
                </td>
                <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($ad->created_at,'d M Y')); ?></td>
                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                    <?php if($ad->status == 1): ?>
                    <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                    <?php else: ?>
                    <span class="badge badge--warning"><?php echo app('translator')->get('Inactive'); ?></span>
                    <?php endif; ?>
                </td>
                
                <td data-label="<?php echo app('translator')->get('Promote'); ?>">
                  <?php if($ad->featured == 1): ?>
                      <?php echo app('translator')->get('Promoted'); ?>
                  <?php elseif($ad->promoted()): ?>
                      <?php echo app('translator')->get('Requested'); ?>
                  <?php else: ?>
                    <a href="<?php echo e(route('user.promote.ad.packages',$ad->slug)); ?>" data-toggle="tooltip" title ="<?php echo app('translator')->get('Promote this ad'); ?>" class="icon-btn btn--success"><i class="las la-bullhorn"></i></a>
                  <?php endif; ?>
                </td>
                <td data-label="Action">
                  <a href="<?php echo e(route('user.ad.edit',$ad->id)); ?>" class="icon-btn btn--primary"><i class="las la-edit"></i></a>
                  <a href="javascript:void(0)" data-route="<?php echo e(route('user.ad.remove',$ad->id)); ?>" class="icon-btn btn--danger delete"><i class="las la-trash-alt"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td colspan="12" class="text-center"><?php echo app('translator')->get('No Ads'); ?></td></tr>
             <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </div>
    <?php echo e(paginateLinks($ads,'partials.paginate')); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/ads/adList.blade.php ENDPATH**/ ?>