<?php
    $footer = getContent('footer.content',true)->data_values;
    $socials = getContent('footer.element',false,'',1);
    $contact = getContent('contact_us.content',true)->data_values;
    $policies  = getContent('policy.element',false,'',1);
?>
<footer class="footer">
    <div class="footer__top">
      <div class="container">
        <div class="row gy-5 justify-content-center">
          <div class="col-lg-6 col-md-8">
            <div class="footer-widget text-center">
              <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="image" class="footer-logo"></a>
              <p class="mt-3"><?php echo e(__($footer->short_details)); ?></p>
            </div><!-- footer-widget end -->
          </div>
        </div><!-- row end -->

        <ul class="social-link-list justify-content-center">
            <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <li>
              <a target="_blank" href="<?php echo e($social->data_values->link); ?>" class="facebook">
                  <?php
                      echo $social->data_values->social_icon;
                  ?>
              </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
              
        <ul class="footer--links">
            <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
            <li><a href="<?php echo e(route('ads')); ?>"><?php echo app('translator')->get('All Ads'); ?></a></li>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('faq')); ?>"><?php echo app('translator')->get('Faq'); ?></a></li>
            <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
        </ul>
      </div>
    </div><!-- footer__top end -->
    <div class="footer__bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 text-lg-start text-center">
            <p><?php echo app('translator')->get('Copyrights'); ?> © <?php echo e(date('Y')); ?> <?php echo app('translator')->get('by'); ?> <a href="<?php echo e(url('home')); ?>" class="text--base"><?php echo e($general->sitename); ?></a> <?php echo app('translator')->get(' All Rights Reserved'); ?> .</p>
          </div>
          <div class="col-lg-6">
              <ul class="help--link-list justify-content-center justify-content-lg-end">
                <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><a href="<?php echo e(route('links',[slug($item->data_values->title),$item->id])); ?>"><?php echo e($item->data_values->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
        </div>
      </div>
    </div>
  </footer>

  <?php if ($__env->exists($activeTemplate.'partials.filterModals')) echo $__env->make($activeTemplate.'partials.filterModals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.depositModal')) echo $__env->make($activeTemplate.'partials.depositModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.paymentOptionModal')) echo $__env->make($activeTemplate.'partials.paymentOptionModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.adReportModal')) echo $__env->make($activeTemplate.'partials.adReportModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.deleteModal')) echo $__env->make($activeTemplate.'partials.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.twofactorModal')) echo $__env->make($activeTemplate.'partials.twofactorModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.paymentHistoryModals')) echo $__env->make($activeTemplate.'partials.paymentHistoryModals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.ticketCloseModal')) echo $__env->make($activeTemplate.'partials.ticketCloseModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php if ($__env->exists($activeTemplate.'partials.imageRemoveModal')) echo $__env->make($activeTemplate.'partials.imageRemoveModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>