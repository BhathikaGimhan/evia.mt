<?php
	$captcha = getCustomCaptcha(46,'100');
?>
<?php if($captcha): ?>
    <div class="form-group row ">
        <div class="col-md-12">
            <?php echo $captcha ?>
        </div>
        <div class="col-md-12 mt-4">
            <input type="text" name="captcha" placeholder="<?php echo app('translator')->get('Enter Code'); ?>" class="form--control" required>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/partials/custom-captcha.blade.php ENDPATH**/ ?>