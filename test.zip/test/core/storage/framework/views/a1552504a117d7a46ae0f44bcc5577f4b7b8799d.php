<?php $__env->startSection('content'); ?>
<div class="row g-3">
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--1">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Total Ad'); ?></h6>
          <a href="<?php echo e(route('user.ad.list')); ?>" class="view-btn"><?php echo app('translator')->get('View'); ?></a>
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($totalAd); ?></div>
        
        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--5">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Total Pending Ad'); ?></h6>
          <a href="<?php echo e(route('user.ad.list')); ?>" class="view-btn"><?php echo app('translator')->get('View'); ?></a>
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($totalPendingAd); ?></div>
        
        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--2">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Saved Ad'); ?></h6>
          <a href="<?php echo e(route('user.saved.ads')); ?>" class="view-btn"><?php echo app('translator')->get('View'); ?></a>
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($totalSaved); ?></div>
         
        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--3">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Refunded Balance'); ?></h6>
          
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($refundedBalance)); ?></div>
         
        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--4">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Total Transactions'); ?></h6>
          <a href="<?php echo e(route('user.trx.history')); ?>" class="view-btn"><?php echo app('translator')->get('View'); ?></a>
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($totalTrx); ?></div>

        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
    <div class="col-xl-4 col-md-6">
      <div class="widget-card widget-color--9">
        <div class="widget-card__header">
          <h6 class="title"><?php echo app('translator')->get('Total Ad Promotion'); ?></h6>
          <a href="<?php echo e(route('user.ad.promotion.log')); ?>" class="view-btn"><?php echo app('translator')->get('View'); ?></a>
        </div>                  
        <div class="widget-card__content">
          <div class="widget-number"><?php echo e($totalPromoted); ?></div>

        </div>
        <div class="widget-card__icon">
          <i class="las la-list"></i>
        </div>
      </div><!-- widget-card end -->
    </div>
   
  </div><!-- row end -->
  <div class="row mt-5">
    <div class="col-lg-12">
      <h3><?php echo app('translator')->get('Latest Ads'); ?></h3>
      <div class="table-responsive--md">
        <div class="table-responsive--md">
          <table class="table custom--table">
            <thead>
              <tr>
                <th><?php echo app('translator')->get('Ad title'); ?></th>
                <th><?php echo app('translator')->get('Date'); ?></th>
                <th><?php echo app('translator')->get('Status'); ?></th>
                <th><?php echo app('translator')->get('Promote'); ?></th>
                <th><?php echo app('translator')->get('Action'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $latestAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td data-label="<?php echo app('translator')->get('Ad title'); ?>">
                  <div class="table-item">
                    <div class="thumb">
                      <img src="<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image,'200x200')); ?>" alt="image">
                    </div>
                    <div class="content">
                      <h6 class="title"><a data-toggle="tooltip" title="<?php echo e($ad->title); ?>" target="_blank" href="<?php echo e(route('ad.details',$ad->slug)); ?>"><?php echo e(shortDescription($ad->title,30)); ?></a></h6>
                    </div>
                  </div>
                </td>
                  <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($ad->created_at,'d M Y')); ?></td>
                  <td data-label="<?php echo app('translator')->get('Status'); ?>">
                      <?php if($ad->status == 1): ?>
                      <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                      <?php else: ?>
                      <span class="badge badge--warning"><?php echo app('translator')->get('Inactive'); ?></span>
                      <?php endif; ?>
                  </td>
                  
                  <td data-label="<?php echo app('translator')->get('Promote'); ?>">
                    <?php if($ad->featured == 1): ?>
                        <?php echo app('translator')->get('Promoted'); ?>
                    <?php elseif($ad->promoted()): ?>
                        <?php echo app('translator')->get('Requested'); ?>
                    <?php else: ?>
                      <a href="<?php echo e(route('user.promote.ad.packages',$ad->slug)); ?>" data-toggle="tooltip" title ="<?php echo app('translator')->get('Promote this ad'); ?>" class="icon-btn btn--success"><i class="las la-bullhorn"></i></a>
                    <?php endif; ?>
                  </td>
                  <td data-label="Action">
                    <a href="<?php echo e(route('user.ad.edit',$ad->id)); ?>" class="icon-btn btn--primary"><i class="las la-edit"></i></a>
                    <a href="javascript:void(0)" data-route="<?php echo e(route('user.ad.remove',$ad->id)); ?>" class="icon-btn btn--danger delete"><i class="las la-trash-alt"></i></a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="12" class="text-center"><?php echo app('translator')->get('No Ads'); ?></td></tr>
               <?php endif; ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>