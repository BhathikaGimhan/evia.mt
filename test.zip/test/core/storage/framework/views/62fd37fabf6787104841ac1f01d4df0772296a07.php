
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
      <div class="col-lg-12 d-flex justify-content-end">
        <form action="">
           <div class="input-group">
             <input class="form-control outline-0 shadow-none" value="<?php echo e($search??''); ?>" type="text" name="search" placeholder="<?php echo app('translator')->get('Search by title'); ?>" required>
              <button type="submit" class="input-group-text bg--sec"><i class="las la-search"></i></button>
           </div>
        </form>
      </div>
      <div class="table-responsive--md">
        <table class="table custom--table">
          <thead>
            <tr>
                <th scope="col"><?php echo app('translator')->get('Ad Title'); ?></th>
                <th scope="col"><?php echo app('translator')->get('Package Name'); ?></th>
                <th scope="col"><?php echo app('translator')->get('Validity'); ?></th>
                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                <th scope="col"><?php echo app('translator')->get('State'); ?></th>
                
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td data-label="<?php echo app('translator')->get('Ad Title'); ?>">
                        <a target="_blank" data-toggle="tooltip" title="<?php echo e($request->ad->title); ?>" href="<?php echo e(route('ad.details',$request->ad->slug)); ?>"><?php echo e(Str::limit($request->ad->title,40)); ?></a>
                    </td>
                   
                    <td data-label="<?php echo app('translator')->get('Package Name'); ?>"><span class="text--small badge font-weight-normal badge--success"><?php echo e($request->package->name); ?></span></td>
                    <td data-label="<?php echo app('translator')->get('Validity'); ?>"><span class="badge badge-pill bg--primary"><?php echo e($request->package->validity); ?> <?php echo app('translator')->get('days'); ?></span></td>
                    <td data-label="<?php echo app('translator')->get('Amount'); ?>"><span class="text--small badge font-weight-normal badge--success"><?php echo e(getAmount($request->package->price)); ?> <?php echo e($general->cur_text); ?></span></td>
                   

                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                        <?php if($request->status == 1): ?>
                            <span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Accepted'); ?></span>
                        <?php elseif($request->status == 0): ?>
                        <span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                        <?php else: ?> 
                        <span class="text--small badge font-weight-normal badge--danger"><?php echo app('translator')->get('Rejected'); ?></span>
                        <?php endif; ?>
                    </td>

                    <td data-label="<?php echo app('translator')->get('Status'); ?>">
                        <?php if($request->running == 1): ?>
                            <span class="text--small badge font-weight-normal badge--primary"><?php echo app('translator')->get('Running'); ?></span>
                        <?php else: ?> 
                        <span class="text--small badge font-weight-normal badge--dark"><?php echo app('translator')->get('Not Running'); ?></span>
                        <?php endif; ?>
                    </td>
                  
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                    </tr>
                <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </div>
    <?php echo e(paginateLinks($requests,'partials.paginate')); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/user/ads/promotionLog.blade.php ENDPATH**/ ?>