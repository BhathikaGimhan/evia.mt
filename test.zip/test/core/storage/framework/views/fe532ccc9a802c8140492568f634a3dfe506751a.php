

<?php $__env->startSection('panel'); ?>

    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Title'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('User'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Category/Subcategory'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Price'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Featured'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Title'); ?>">
                                    <div class="user">
                                        <div class="thumb"><img src="<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image,'100x100')); ?>" alt="image"></div>
                                        <span class="name"><a class="text-secondary" href="<?php echo e(route('ad.details',$ad->slug)); ?>" target="_blank"><?php echo e($ad->title); ?></a></span> <br>
                                    </div>
                                   
                                </td>
                                <td data-label="<?php echo app('translator')->get('User'); ?>"><a href="<?php echo e(route('admin.users.detail',$ad->user->id)); ?>"><?php echo e($ad->user->username); ?></a></td>
                                <td data-label="<?php echo app('translator')->get('Category/Subcategory'); ?>">
                                    <span class="text--warning font-weight-bold"><?php echo e($ad->category->name); ?></span> <br>
                                    <span class="text--primary"><?php echo e($ad->subcategory->name); ?></span>
                                </td>
                              
                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e(getAmount($ad->price)); ?> <?php echo e($general->cur_text); ?></td>
                                <td data-label="<?php echo app('translator')->get('Featured'); ?>">
                                    <?php if($ad->featured == 1): ?>
                                    <span class="badge badge-pill bg--primary"><?php echo app('translator')->get('Yes'); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-pill bg--dark"><?php echo app('translator')->get('No'); ?></span>
                                    <?php endif; ?>
                                
                                </td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($ad->status == 1): ?>
                                    <span class="text--small badge font-weight-normal badge--success"><?php echo app('translator')->get('Published'); ?></span>
                                    <?php elseif($ad->status == 2): ?>
                                    <span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Unpublished'); ?></span>
                                    <?php else: ?>
                                    <span class="text--small badge font-weight-normal badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="<?php echo e(route('admin.ads.edit',$ad->id)); ?>" class="icon-btn mr-2" data-toggle="tooltip" title="<?php echo app('translator')->get('Edit'); ?>">
                                        <i class="las la-edit text--shadow"></i>
                                    </a>
                                    <?php if($ad->status == 1): ?>
                                    <a href="javascript:void(0)" data-route="<?php echo e(route('admin.ads.status',$ad->id)); ?>" class="confirm icon-btn btn--dark" data-toggle="tooltip" title="<?php echo app('translator')->get('Unpublish'); ?>">
                                        <i class="las la-undo"></i>
                                    </a>
                                    <?php else: ?>
                                    <a href="javascript:void(0)" data-route="<?php echo e(route('admin.ads.status',$ad->id)); ?>" data-publish="1"  class="confirm icon-btn btn--success" data-toggle="tooltip" title="<?php echo app('translator')->get('Publish'); ?>">
                                        <i class="las la-share-square"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e($empty_message); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($ads)); ?>

                </div>
            </div><!-- card end -->
        </div>


    </div>

    <div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <button type="button" class="close ml-auto m-3" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body text-center">
                    
                    <i class="las la-exclamation-circle text--warning modal-icon display-2 mb-15"></i>
                    <h4 class="text--secondary stat-msg mb-15"><?php echo app('translator')->get('Are you sure want to unpublish?'); ?></h4>

                </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                <button type="submit"  class="btn btn--warning del"><?php echo app('translator')->get('Unpublish'); ?></button>
            </div>
            
            </form>
        </div>
    </div>
            </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('breadcrumb-plugins'); ?>
    
<form action="" method="GET" class="form-inline float-sm-right bg--white">
    <div class="input-group has_append">
        <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('title, category'); ?>" value="<?php echo e($search??''); ?>">
        <div class="input-group-append">
            <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
        </div>
    </div>
</form>

<?php $__env->stopPush(); ?>

    
<?php $__env->startPush('script'); ?>
     <script>
            'use strict';
            (function ($) {
                $('.confirm').on('click',function(){
                    var route = $(this).data('route')
                    var modal = $('#confirmModal');
                    var publish = $(this).data('publish')
                    if(publish == 1){
                        $('#confirmModal').find('.modal-icon').removeClass('text--warning').addClass('text--success')
                        $('#confirmModal').find('.del').removeClass('btn--warning').addClass('btn--success').text('Publish')
                        $('#confirmModal').find('.stat-msg').text('Are you sure want to publish?')
                    }
                    modal.find('form').attr('action',route)
                    modal.modal('show');
                })
            })(jQuery);
     </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/admin/ads/allAds.blade.php ENDPATH**/ ?>