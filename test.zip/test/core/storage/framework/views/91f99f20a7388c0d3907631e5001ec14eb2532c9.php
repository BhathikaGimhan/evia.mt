
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-1 shadow-sm p-4">
                <div class="card-header border-0 bg-transparent text-center">
                    <h5><?php echo app('translator')->get('Select Location Below.'); ?></h5>
                   
                </div>
                <div class="card-body">
                    <ul class="select-menu-list">
                        <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="has-drop-menu">
                          <a href="javascript:void(0)">
                            <img src="<?php echo e(getImage('assets/images/location/'.$division->image)); ?>" alt="location" class="select-menu-img">
                            <span><?php echo e(__($division->name)); ?></span>
                          </a>
                          <ul class="drop-menu">
                            <?php $__currentLoopData = $division->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <li>
                              <a href="<?php echo e(route('user.post.ad.form',[$type,$subcat,$district->slug])); ?>">
                                <i class="las la-caret-right"></i>
                                <span><?php echo e(__($district->name)); ?></span>
                              </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                          </ul>
                        </li>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="text-center"><?php echo app('translator')->get('No locations available'); ?></li>
                        <?php endif; ?>
                        
                      </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/ads/postAdLocation.blade.php ENDPATH**/ ?>