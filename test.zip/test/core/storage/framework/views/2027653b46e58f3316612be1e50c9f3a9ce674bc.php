<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /home/randcopf/evia.mt/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>