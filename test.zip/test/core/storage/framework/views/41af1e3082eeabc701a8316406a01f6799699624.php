
<?php $__env->startSection('content'); ?>
    <div class="row">
      <div class="col-lg-12 d-flex justify-content-end">
        <form action="">
           <div class="input-group">
             <input class="form-control outline-0 shadow-none" value="<?php echo e($search??''); ?>" type="text" name="search" placeholder="<?php echo app('translator')->get('Search by trx'); ?>" required>
              <button type="submit" class="input-group-text bg--sec"><i class="las la-search"></i></button>
           </div>
        </form>
      </div>
        <div class="col-lg-12">
          <div class="table-responsive--md">
            <table class="table custom--table m-0">
              <thead>
                <tr>
                    <th scope="col"><?php echo app('translator')->get('Trx ID'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Charge'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Details'); ?></th>
                    <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                </tr>
              </thead>
              <tbody>
                
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('Transaction ID'); ?>"><?php echo e($data->trx); ?></td>
                            <td data-label="<?php echo app('translator')->get('Amount'); ?>"><?php echo e(getAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></td>
                            <td data-label="<?php echo app('translator')->get('Charge'); ?>"><?php echo e(getAmount($data->charge)); ?> <?php echo e($general->cur_text); ?></td>
                            <td data-label="<?php echo app('translator')->get('Trx Type'); ?>">
                                <?php if($data->trx_type == '+'): ?>
                                <span class="badge badge--success"><i class="las la-plus"></i></span>
                                <?php else: ?>
                                <span class="badge badge--danger"><i class="las la-minus"></i></span>
                                <?php endif; ?>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Details'); ?>"><?php echo e(__($data->details)); ?></td>
                            <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($data->created_at,'d-m-Y')); ?></td>
                           
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="100%"> <?php echo app('translator')->get('No data found'); ?>!</td>
                        </tr>
                    <?php endif; ?>
                
              </tbody>
            </table>
          </div>
        </div>
        <?php echo e(paginateLinks($logs,'partials.paginate')); ?>

        
      </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/user/transactions.blade.php ENDPATH**/ ?>