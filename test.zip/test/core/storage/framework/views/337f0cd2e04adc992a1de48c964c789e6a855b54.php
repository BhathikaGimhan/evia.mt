<?php
     $elements= getContent('counter.element',false,'',1);
?>

<section class="pt-50 pb-50">
    <div class="container">
        <div class="counter-wrapper">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="counter-item">
                    <div class="thumb">
                        <span class="odometer" data-odometer-final="<?php echo e(@intval($item->data_values->digit)); ?>">0</span>
                        <span><?php echo e(@ucwords(@preg_replace("/[^a-zA-Z]+/", "", $item->data_values->digit))); ?></span>
                    </div>
                    <div class="counter-content">
                        <h5 class="title"><?php echo app('translator')->get($item->data_values->title); ?></h5>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          

    </div>
</section><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/sections/counter.blade.php ENDPATH**/ ?>