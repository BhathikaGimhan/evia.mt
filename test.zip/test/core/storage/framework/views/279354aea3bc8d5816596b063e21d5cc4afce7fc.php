<?php
      $elements= getContent('how.element',false,'',1);
?>

  <!-- How Section Starts -->
  <section class="how-section section--bg pt-50 pb-50">
    <div class="container">
        <div class="row g-4 justify-content-center">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="how__item">
                    <div class="shape-bg">
                        <?php if($loop->odd): ?>
                        <img src="<?php echo e(asset($activeTemplateTrue.'images/how-shape2.png')); ?>" alt="<?php echo app('translator')->get('images'); ?>">
                        <?php else: ?>
                        <img src="<?php echo e(asset($activeTemplateTrue.'images/how-shape.png')); ?>" alt="<?php echo app('translator')->get('images'); ?>">
                        <?php endif; ?>
                    </div>
                  <div class="how__thumb">
                    <?php
                        echo $item->data_values->icon;
                    ?>
                  </div>
                  <div class="how__content">
                      <h5 class="title"><?php echo app('translator')->get($item->data_values->title); ?></h5>
                  </div>
              </div>
            </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </div>
    </div>
</section>
<!-- How Section End -->
<?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/sections/how.blade.php ENDPATH**/ ?>