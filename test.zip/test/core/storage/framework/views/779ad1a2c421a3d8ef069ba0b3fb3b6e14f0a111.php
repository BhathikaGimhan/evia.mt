      <!-- header-section start  -->
      <header class="header">
        <div class="header__bottom">
          <div class="container-fluid">
            <nav class="navbar navbar-expand-xl p-0 align-items-center">
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
              </button>
              <a class="site-logo site-title" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo"></a>
              <div class="collapse navbar-collapse mt-lg-0 mt-3" id="navbarSupportedContent">
                <ul class="navbar-nav main-menu ms-auto">
                  <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
                  <li><a href="<?php echo e(route('ads')); ?>"><?php echo app('translator')->get('All Ads'); ?></a></li>
                  <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e(route('pages',[$data->slug])); ?>"><?php echo e(__($data->name)); ?></a></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="<?php echo e(route('faq')); ?>"><?php echo app('translator')->get('Faq'); ?></a></li>
                  <?php if(auth()->guard()->guest()): ?>
                  <li><a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a></li>
                  <?php endif; ?>
                  <?php if(auth()->guard()->check()): ?>
                  <li><a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support'); ?></a></li>
                  <li><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
                  <li><a href="<?php echo e(route('user.logout')); ?>"><?php echo app('translator')->get('logout'); ?></a></li>
                  <?php endif; ?>
                  <?php if(auth()->guard()->guest()): ?>
                  <li><a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a></li>
                  <?php endif; ?>
                </ul>
                <div class="nav-right">
                  <a href="<?php echo e(route('user.post.ad')); ?>" class="btn btn-md btn--base d-lg-inline-flex align-items-center m-1"><i class="las la-file-alt font-size--18px me-2"></i> <?php echo app('translator')->get('Post Ad'); ?></a>
                  <select class="language-select ms-lg-3 m-1 langSel">
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
            </nav>
          </div>
        </div><!-- header__bottom end -->
      </header>
      <!-- header-section end  --><?php /**PATH /home/randcopf/evia.mt/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>