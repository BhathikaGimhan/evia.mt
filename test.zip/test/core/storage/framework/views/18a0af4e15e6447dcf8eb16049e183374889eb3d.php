<?php $__env->startSection('content'); ?>
      <!-- category section start -->
      <div class="pt-50 pb-50">
        <div class="container">
          <div class="item-search-wrapper">
            <div class="row gy-3">
              <div class="col-lg-3 col-md-6">
                <button type="button" class="item-search-btn w-100 rounded-3" data-bs-toggle="modal" data-bs-target="#locationModal"><i class="las la-map-marker"></i>
                  <?php if($distrct): ?>
                      <?php echo e($distrct->name); ?>

                  <?php elseif(request()->input('division')): ?>
                      <?php echo e(ucwords(request()->input('division'))); ?>

                  <?php else: ?>
                    <?php echo app('translator')->get('Select Location'); ?>
                  <?php endif; ?>
                </button>
              </div>
              <div class="col-lg-3 col-md-6">
                <button type="button" class="item-search-btn w-100 rounded-3" data-bs-toggle="modal" data-bs-target="#categoryModal"><i class="las la-tag"></i>
                  <?php if($subcategory): ?>
                    <?php echo e($subcategory->name); ?>

                  <?php elseif(request()->input('category')): ?>
                      <?php echo e(ucwords(request()->input('category'))); ?>

                  <?php else: ?>
                    <?php echo app('translator')->get('Select Category'); ?>
                  <?php endif; ?>
                </button>
              </div>
              <div class="col-lg-6">
                <form class="item-search-form" method="GET" action="" id="searchForm">
                  <input type="text" name="search" id="search" class="form--control" placeholder="<?php echo app('translator')->get('Search in here'); ?>...">
                  <button type="submit" class="item-search-form-btn"><i class="las la-search"></i></button>
                </form>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-xl-3 col-lg-3">
              <button class="filter-open-btn mb-3"><i class="las la-bars"></i> <?php echo app('translator')->get('Filter'); ?></button>
              <div class="sidebar filter-sidebar">
                <button class="sidebar-close-btn"><i class="las la-times"></i></button>
                <div class="form-group mb-3">
                  <label for="my-select"><?php echo app('translator')->get('Sort results by'); ?></label>
                  <select class="form--control" onChange="window.location.href=this.value">
                    <option value="<?php echo e(queryBuild('sortby','date_desc')); ?>" <?php echo e(request()->input('sortby')=='date_desc'? 'selected':''); ?>><?php echo app('translator')->get('Date: Newest on top'); ?></option>
                    <option value="<?php echo e(queryBuild('sortby','date_asc')); ?>" <?php echo e(request()->input('sortby')=='date_asc'? 'selected':''); ?>><?php echo app('translator')->get('Date: Oldest on top'); ?></option>
                    <option value="<?php echo e(queryBuild('sortby','price_desc')); ?>" <?php echo e(request()->input('sortby')=='price_desc'? 'selected':''); ?>><?php echo app('translator')->get('Price: High to Low'); ?></option>
                    <option value="<?php echo e(queryBuild('sortby','price_asc')); ?>" <?php echo e(request()->input('sortby')=='price_asc'? 'selected':''); ?>><?php echo app('translator')->get('Price: Low to High'); ?></option>
                  </select>
                </div>

                <?php if($subcategory): ?>
                <div class="mb-3">
                  <span class="mb-2"><?php echo app('translator')->get('Type'); ?></span>
                  <select class="select" name="condition" onChange = 'window.location.href=this.value'>
                    <option value=""><?php echo app('translator')->get('Choose Option'); ?></option>
                    <option value="<?php echo e(queryBuild('type',1)); ?>" <?php echo e(request()->input('type') == 1 ? 'selected':''); ?>><?php echo app('translator')->get('Sell'); ?></option>
                    <option value="<?php echo e(queryBuild('type',2)); ?>" <?php echo e(request()->input('type') == 2 ? 'selected':''); ?> ><?php echo app('translator')->get('Rent'); ?></option>
                  </select>
                </div>
                  <div class="mt-2 mb-4">
                    <span class="mb-2"><?php echo app('translator')->get('Condition'); ?></span>
                    <select class="select" name="condition" onChange = 'window.location.href=this.value'>
                      <option value=""><?php echo app('translator')->get('Choose Option'); ?></option>
                      <option value="<?php echo e(queryBuild('condition',2)); ?>" <?php echo e(request()->input('condition') == 2?'selected':''); ?>><?php echo app('translator')->get('Used'); ?></option>
                      <option value="<?php echo e(queryBuild('condition',1)); ?>" <?php echo e(request()->input('condition')==1?'selected':''); ?> ><?php echo app('translator')->get('New'); ?></option>
                    </select>
                  </div>
                <?php endif; ?>

                <div class="sidebar-widget">
                  <h4 class="sidebar-widget__title">
                    <span><?php echo app('translator')->get('Category'); ?></span>
                    <button class="title-btn"><i class="las la-angle-down"></i></button>
                  </h4>
                  <div class="sidebar-widget__body">
                    <ul class="sidebar-menu">
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                      <li class="sidebar-dropdown <?php echo e(request()->input('category') == $cat->slug ?'active':''); ?> <?php echo e(@$subcategory->category->slug == $cat->slug ? 'active':''); ?>">
                        <?php
                            $excpCat = http_build_query(request()->except('category','location')).'location='.request()->input('location');
                        ?>
                        <a data-toggle="tooltip" title="<?php echo e($cat->description); ?>" href="<?php echo e($subcategory ? url('/items/')."?category=$cat->slug"."&$excpCat": queryBuild('category',$cat->slug)); ?>"><img src="<?php echo e(getImage('assets/images/category/'.$cat->image)); ?>" alt="image" class="sidebar-menu-img"> <?php echo e(__($cat->name)); ?></a>
                        <div class="sidebar-submenu">
                          <ul>
                            <?php $__currentLoopData = $cat->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty(request()->input())): ?>
                            <li class="sidebar-menu-item">
                              <a href="<?php echo e(url('/items/')."/$subcat->slug"."?location=".request()->input('location')); ?>" class="<?php echo e(@$subcategory->id == $subcat->id?'text-dark':''); ?>"><?php echo e($subcat->name); ?><span><?php echo e(getAmount($subcat->totalAd())); ?></span></a>
                            </li>
                            <?php else: ?>
                            <li class="sidebar-menu-item">
                              <a href="<?php echo e(url('/items/')."/$subcat->slug"); ?>" class="<?php echo e(@$subcategory->id == $subcat->id?'text-dark':''); ?>"><?php echo e($subcat->name); ?><span><?php echo e(getAmount($subcat->totalAd())); ?></span></a>
                            </li>
                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </ul>
                        </div>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul><!-- sidebar-menu end -->
                  </div>
                </div><!-- sidebar-widget -->
                <div class="sidebar-widget">
                  <h4 class="sidebar-widget__title">
                    <span><?php echo app('translator')->get('Location'); ?></span>
                    <button class="title-btn"><i class="las la-angle-down"></i></button>
                  </h4>
                  <div class="sidebar-widget__body">
                    <ul class="sidebar-menu">
                     <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $divsion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <li class="sidebar-dropdown <?php echo e(request()->input('division') == $divsion->slug ? 'active':''); ?> <?php echo e(@$distrct->division->slug == $divsion->slug ? 'active':''); ?>">
                      <?php
                      $excpDiv = http_build_query(request()->except('division','location')).'location=';
                      ?>
                      <a href="<?php echo e($subcategory ? url('/items/')."/$subcategory->slug"."?division=$divsion->slug"."&$excpDiv" : queryBuild('division',$divsion->slug )); ?>"><img src="<?php echo e(getImage('assets/images/location/'.$divsion->image)); ?>" alt="image" class="sidebar-menu-img"> <?php echo e(__($divsion->name)); ?></a>
                      <div class="sidebar-submenu">
                        <ul>
                          <?php $__currentLoopData = $divsion->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          <li class="sidebar-menu-item">
                            <a href="<?php echo e(queryBuild('location',$district->slug)); ?>"><?php echo e($district->name); ?><span><?php echo e(getAmount($district->totalAd())); ?></span></a>
                          </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                      </div>
                    </li>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul><!-- sidebar-menu end -->
                  </div>
                </div><!-- sidebar-widget end -->

                <div class="sidebar-widget">
                  <h4 class="sidebar-widget__title">
                    <div class="sidebar-widget__body mt-2">
                      <?php if($subcategory): ?>
                        <?php if($subcategory->fields->count() > 0): ?>
                           <?php $__currentLoopData = $subcategory->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($field->type == 2 || $field->type == 3): ?>
                                  <div class="form-group col-lg-12">
                                      <?php if($field->type == 2 &&  $field->as_filter == 1): ?>
                                      <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?> </label>
                                      <select class="form--control"  onChange="window.location.href=this.value">
                                        <option value=""><?php echo app('translator')->get('Choose Option'); ?></option>
                                          <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e(queryBuild($field->name,slug($opt))); ?>" <?php echo e(request()->input($field->name)==slug($opt)?'selected':''); ?>><?php echo e($opt); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                      <?php elseif($field->type == 3 &&  $field->as_filter == 1): ?>
                                          <label class="font-weight-bold"><?php echo app('translator')->get($field->label); ?></label>
                                          <select class="form--control"  onChange="window.location.href=this.value">
                                            <option value=""><?php echo app('translator')->get('Choose Option'); ?></option>
                                              <?php $__currentLoopData = $field->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                  <option value="<?php echo e(queryBuild($field->name,slug($opt))); ?>" <?php echo e(request()->input($field->name)== slug($opt)?'selected':''); ?>><?php echo e($opt); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </select>
                                      <?php endif; ?>
                                  </div>
                              <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      <?php endif; ?>

                      <?php if($subcategory): ?>
                       <form action="" class="filterForm" method="GET">
                        <div class="row">
                          <label><?php echo app('translator')->get('Price'); ?></label>
                          <div class="col-md-6">
                            <input class="form--control" name="min" id="min" type="text" placeholder="<?php echo app('translator')->get('min'); ?>" value="<?php echo e(request()->input('min')); ?>">
                          </div>
                          <div class="col-md-6">
                            <input class="form--control" name="max" id="max" type="text" placeholder="<?php echo app('translator')->get('max'); ?>" value="<?php echo e(request()->input('max')); ?>">
                          </div>
                          <div class="col-md-12">
                            <button class="btn btn--base btn-sm w-100 mt-2" type="submit"><?php echo app('translator')->get('Apply'); ?></button>
                          </div>
                        </div>
                      </form>
                      <?php endif; ?>

                    </div>
                  </h4>
                </div><!-- sidebar-widget end -->
              </div><!-- sidebar end -->
              <div class="d-sm-none text-center d-lg-block mt-4">
                <?php
                    echo advertisements('300x250');
                ?>
              </div>
              <div class="d-none d-sm-block d-lg-none mt-4 text-center">
                <?php
                    echo advertisements('970x90');
                ?>
              </div>
            </div>
            <div class="col-xl-9 col-lg-9 pl-lg-5 mt-5 mt-lg-0">
              <ul class="page-link-inline-menu mb-3">
                <li><?php echo app('translator')->get('Home'); ?></li>
                <li><?php echo app('translator')->get('Items'); ?></li>
                <?php if($distrct): ?>
                  <li><?php echo e($distrct->name); ?></li>
                <?php endif; ?>
                <?php if($subcategory): ?>
                 <li><?php echo e($subcategory->name); ?></li>
                <?php endif; ?>

              </ul>
              <?php if(Route::currentRouteName() == 'ads'): ?>
                <?php echo $__env->make($activeTemplate.'partials.featuredList',['featuredAds' => $featuredAds], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endif; ?>

              <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                <?php
                    $slug = $ad->subcategory->slug;
                ?>
                <div class="list-item list--style">
                  <div class="list-item__thumb">
                    <a href="<?php echo e(route('ad.details',$ad->slug)); ?>"><img src="<?php echo e(getImage('assets/images/item_image/'.$ad->prev_image,'275x200')); ?>" alt="image"></a>
                  </div>
                  <div class="list-item__wrapper">
                    <div class="list-item__content">
                      <a href="<?php echo e(url('/items/')."/$slug"."?location=".request()->input('location')); ?>" class="category text--base"><i class="las la-tag"></i> <?php echo e($ad->subcategory->name); ?></a>
                      <h6 class="title"><a href="<?php echo e(route('ad.details',$ad->slug)); ?>"><?php echo e(__($ad->title)); ?></a></h6>
                      <ul class="list-item__meta mt-1">
                        <li>
                          <i class="las la-clock"></i>
                          <span><?php echo e(diffForHumans($ad->created_at)); ?></span>
                        </li>
                        <li>
                          <i class="las la-user"></i>
                          <a href="javascript:void(0)"><?php echo e($ad->user->fullname); ?></a>
                        </li>
                        <li>
                          <i class="las la-map-marker"></i>
                          <span><?php echo e($ad->district); ?>, <?php echo e($ad->division); ?></span>
                        </li>
                      </ul>
                      <ul>
                        <li>
                            <span style="background-color: #43CED2; border-radius:10px; padding:8px; color:white;"><?php echo e($ad->ownership); ?></span>
                          </li>
                      </ul>
                    </div>
                    <div class="list-item__footer">
                      <div class="price"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($ad->price)); ?></div>
                      <a href="<?php echo e(route('ad.details',$ad->slug)); ?>" class="btn btn-sm btn--base mt-2"><?php echo app('translator')->get('View Details'); ?></a>
                    </div>
                  </div>
                </div><!-- list-item end -->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($ads->count() == 0 && $featuredAds->count() == 0): ?>
              <div class="list-item list--style">
                <div class="list-item__thumb">
                  <a href="javascript:void(0)"><img src="<?php echo e(getImage('assets/images/noad.png')); ?>" alt="image"></a>
                </div>
                <div class="list-item__wrapper">
                  <div class="list-item__content d-flex align-items-center justify-content-center">
                    <h5 class="h5"><?php echo app('translator')->get('Sorry No Ads Found!!'); ?></h5>
                  </div>
                </div>
              </div>
              <?php endif; ?>

             <?php echo e(paginateLinks($ads)); ?>

            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php
  $url =  http_build_query(request()->except('min','max'));
  $url = str_replace("amp%3B","",$url);

  $searchUrl =  http_build_query(request()->except('search'));
  $searchUrl =   str_replace("amp%3B","",$searchUrl);

  $queryStrings = json_encode(request()->query());
?>
<?php $__env->startPush('script'); ?>
<script>
  'use strict';
  $('.filterForm').on('submit',function(e){
    e.preventDefault();
    var data = $(this).serialize();
    var url = '<?php echo e(url()->current()); ?>?<?php echo e($url); ?>';
    url = url.replaceAll('amp;','');
    var queryString = "<?php echo e($queryStrings); ?>"
    var delim;
    if(queryString.length > 2){
       delim = "&"
    }else {
       delim = ""
    }
    window.location.href = url+delim+data;
  });

  $('#searchForm').on('sumit',function(e){
    e.preventDefault();
    var data = $(this).serialize();
    var url = '<?php echo e(url()->current()); ?>?<?php echo e($searchUrl); ?>';
    url = url.replaceAll('amp;','');
    var queryString = "<?php echo e($queryStrings); ?>"
    var delim;
    if(queryString.length > 2){
       delim = "&"
    }else {
       delim = ""
    }
    window.location.href = url+delim+data;
  });


  $('.advert').on('click',function () {
        var ad_id = $(this).data('advertid')
        var data = {
          ad_id:ad_id
        }
        var route = "<?php echo e(route('ad.click')); ?>"
        axios.post(route,data).then(function (res) { })
  })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/randcopf/demo.randika.pw/core/resources/views/templates/basic/allAds.blade.php ENDPATH**/ ?>